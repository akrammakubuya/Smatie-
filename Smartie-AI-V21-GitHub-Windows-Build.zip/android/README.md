# Smartie AI V17 Android

Open this `android/` folder in Android Studio. Build the debug APK for your Samsung S-series device.

V17 includes native alarms, reboot restoration, TTS, notification permissions, connectivity detection, device capability reporting, and a local OpenAI-compatible AI adapter.

A local model runtime is not bundled. Configure its endpoint from the V17 controls inside the app.


V17 adds capability-aware AI routing so the same APK can adapt to different Android phones. It recommends a local model class from device resources and can test a configured local OpenAI-compatible endpoint.
