# Smartie Personal Phone Deploy V10

V10 adds the Voice Engine.

Features:
- Browser speech-to-text using the device/browser speech recognition API where supported.
- Browser text-to-speech for Smartie's spoken replies.
- Voice enable/disable per profile.
- Saved speech rate, pitch and preferred voice.
- Stop speaking control.
- English-Uganda speech recognition preference.
- No external speech API or API key required.

V9 Knowledge Brain and all previous engines remain included.

Note: speech recognition and available voices depend on the browser and Android device. This version intentionally uses native browser capabilities to keep the phone deployment lightweight and avoid new API costs.
