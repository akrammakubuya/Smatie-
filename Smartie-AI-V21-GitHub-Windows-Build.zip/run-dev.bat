@echo off
setlocal
cd /d "%~dp0"
if not exist node_modules (
  echo First run: installing dependencies...
  call npm install
  if errorlevel 1 (echo npm install failed.&pause&exit /b 1)
)
call npm run dev
pause
