# Smartie Personal Phone Deploy V18

## Adaptive Runtime & Model Manager

V18 extends V17 so Smartie can make a capability-aware decision before claiming that local AI is available.

### What V18 adds
- Native Android capability report: RAM, CPU cores, ABI, free storage, battery and thermal status.
- Native CPU benchmark plus browser fallback benchmark.
- Capability tiers remain advisory, not a guarantee.
- Runtime verification probe for an OpenAI-compatible local endpoint.
- Local AI is marked **verified** only when the configured runtime returns a valid chat-completion shape.
- Automatic route concept: cloud-first, local, hybrid, or cloud.
- Model-class recommendations instead of forcing one model on every phone.
- Model/runtime manager UI.
- Battery/thermal information can be used to prefer cloud fallback when local inference is inappropriate.
- Keeps the V13 security/sync foundation, V14 Agent Engine, V15 Android layer, V16 local adapter and V17 adaptive detection.

### Important limitation
V18 does not silently download a third-party model. A production model marketplace/download system requires a trusted model catalog, checksums/signatures, storage management and a compatible on-device runtime. V18 provides the decision and verification layer first.

### Android
Open the `android/` folder in Android Studio. The Android project is version 18.0.0.
