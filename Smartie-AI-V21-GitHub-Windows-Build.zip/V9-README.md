# Smartie Personal Phone Deploy V9

V9 adds the local Document / Knowledge Brain.

Features:
- Store personal notes and documents per profile.
- Search saved knowledge with SQLite FTS5.
- Open stored document content.
- Delete documents.
- Browser-side import for text/markdown/JSON/CSV/code/HTML/CSS/XML files.
- Pasted text capture for any document format.
- Backend extraction helpers for DOCX/PDF are included when system tools are available.
- Knowledge remains separate from conversational memory.
- V8 proactive intelligence and earlier engines remain included.

For large or complex PDFs, OCR-heavy scans, and advanced semantic retrieval, a later version can add a dedicated document processing pipeline.
