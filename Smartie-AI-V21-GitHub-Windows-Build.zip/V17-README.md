# Smartie Personal Phone Deploy V17

V17 adds an adaptive AI runtime layer designed to work across many Android phones rather than targeting one Samsung model.

## Adaptive device intelligence
- Detects manufacturer, model, Android version, RAM, CPU cores, ABI and low-RAM status on Android.
- Classifies the device as cloud-first, tiny-local, small-local, medium-local or strong-local.
- Recommends a model size class instead of forcing one model on every phone.
- Supports automatic, local-first, hybrid and cloud-first routing.
- Can test an OpenAI-compatible local model endpoint from the native Android layer.

## Important
Capability detection is a recommendation system, not a guarantee of inference speed. Thermals, free RAM, storage, GPU/NPU support and the installed runtime also matter. Smartie therefore treats a local model as ready only after a successful runtime test/benchmark.

V17 does not bundle a model because different phones need different model sizes and runtimes. It can connect to a suitable small local runtime when one is available and retain cloud fallback when it is not.
