package com.studysmart.smartie

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import java.util.UUID

/** Small HTTP bridge embedded in the APK. The WebView talks to this localhost server,
 * so the installed app does not need Node.js, Express, Chrome or a project directory. */
class LocalServer(private val context: Context, private val port: Int = 8787) {
    private val db = Store(context)
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            try {
                server = ServerSocket(port, 50, java.net.InetAddress.getByName("127.0.0.1"))
                while (running) {
                    val s = server!!.accept()
                    Thread { handle(s) }.start()
                }
            } catch (_: Exception) { }
        }.also { it.start() }
    }

    fun stop() { running = false; try { server?.close() } catch (_: Exception) {} }

    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 60000
                val input = BufferedInputStream(s.getInputStream())
                val reader = BufferedReader(InputStreamReader(input, Charsets.UTF_8))
                val request = reader.readLine() ?: return
                val parts = request.split(" ")
                if (parts.size < 2) return
                val method = parts[0]
                val target = parts[1]
                var contentLength = 0
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    val lower = line.lowercase()
                    if (lower.startsWith("content-length:")) contentLength = line.substringAfter(":").trim().toIntOrNull() ?: 0
                }
                val body = if (contentLength > 0) {
                    val chars = CharArray(contentLength); var off = 0
                    while (off < contentLength) { val n = reader.read(chars, off, contentLength-off); if (n < 0) break; off += n }
                    String(chars, 0, off)
                } else ""
                val response = route(method, target, body)
                writeResponse(s, response.first, response.second)
            } catch (e: Exception) {
                try { writeResponse(s, 500, JSONObject().put("error", e.message ?: "Server error").toString()) } catch (_: Exception) {}
            }
        }
    }

    private fun route(method: String, target: String, body: String): Pair<Int,String> {
        val path = target.substringBefore("?")
        val query = parseQuery(target.substringAfter("?", ""))
        try {
            when {
                method == "GET" && (path == "/" || path == "/index.html") -> return Pair(200, context.assets.open("index.html").bufferedReader().use { it.readText() })
                method == "GET" && path == "/manifest.webmanifest" -> return Pair(200, context.assets.open("manifest.webmanifest").bufferedReader().use { it.readText() })
                method == "GET" && path == "/icon.svg" -> return Pair(200, context.assets.open("icon.svg").bufferedReader().use { it.readText() })
                method == "GET" && path == "/api/health" -> return ok(JSONObject().put("ok",true).put("mode","standalone").put("server","android-local"))
                method == "GET" && path.startsWith("/api/profile/") -> return ok(db.profile(path.substringAfterLast('/')))
                method == "PUT" && path.startsWith("/api/profile/") -> { db.saveProfile(path.substringAfterLast('/'), JSONObject(body)); return ok(db.profile(path.substringAfterLast('/'))) }
                method == "GET" && path.startsWith("/api/chats/") && path.endsWith("/messages") -> return ok(db.messages(path.split('/').getOrNull(3) ?: ""))
                method == "GET" && path.startsWith("/api/chats/") -> return ok(db.chats(path.substringAfterLast('/')))
                method == "POST" && path == "/api/chats" -> return ok(db.newChat(JSONObject(body).optString("profile_id","guest"), JSONObject(body).optString("title","New conversation")))
                method == "POST" && path.startsWith("/api/chats/") && path.endsWith("/messages") -> { db.addMessages(path.split('/').getOrNull(3) ?: "", JSONObject(body)); return ok(JSONObject().put("ok",true)) }
                method == "POST" && path == "/api/chat" -> return chat(JSONObject(body))
                method == "GET" && path.startsWith("/api/memories/") -> return ok(db.memories(path.substringAfterLast('/')))
                method == "POST" && path == "/api/memories" -> { val x=db.addMemory(JSONObject(body)); return ok(x) }
                method == "DELETE" && path.startsWith("/api/memories/") -> { db.deleteMemory(path.substringAfterLast('/')); return ok(JSONObject().put("ok",true)) }
                method == "POST" && path == "/api/memories/forget" -> { db.forgetMemories(JSONObject(body).optString("profile_id","guest"), JSONObject(body).optString("query")); return ok(JSONObject().put("ok",true)) }
                method == "GET" && path == "/api/projects/" -> return ok(JSONArray())
                method == "GET" && path.startsWith("/api/projects/") -> return ok(db.projects(path.substringAfterLast('/')))
                method == "POST" && path == "/api/projects" -> return ok(db.addProject(JSONObject(body)))
                method == "PUT" && path.startsWith("/api/projects/") -> return ok(db.updateProject(path.substringAfterLast('/'), JSONObject(body)))
                method == "DELETE" && path.startsWith("/api/projects/") -> { db.deleteProject(path.substringAfterLast('/')); return ok(JSONObject().put("ok",true)) }
                method == "GET" && path.startsWith("/api/tasks/") -> return ok(db.tasks(path.substringAfterLast('/')))
                method == "POST" && path == "/api/tasks" -> return ok(db.addTask(JSONObject(body)))
                method == "PATCH" && path.startsWith("/api/tasks/") -> return ok(db.updateTask(path.substringAfterLast('/'), JSONObject(body)))
                method == "DELETE" && path.startsWith("/api/tasks/") -> { db.deleteTask(path.substringAfterLast('/')); return ok(JSONObject().put("ok",true)) }
                method == "GET" && path == "/api/developer" -> return ok(JSONObject().put("name","Makubuya Akram").put("role","Creator / Developer").put("public_context","Akram is the creator and developer of Smartie AI.").put("projects",JSONArray().put("StudySmart UG").put("StudySmart SmartClass").put("Smartie AI")))
                method == "GET" && path == "/api/brain/search" -> return ok(db.brain(query["q"] ?: "", query["profile_id"] ?: "guest"))
                method == "POST" && path == "/api/suggest-memories" -> return ok(JSONObject().put("suggestions",JSONArray()))
                method == "GET" && path.startsWith("/api/proactive/") -> return ok(JSONObject().put("insights",JSONArray()))
                method == "POST" && path.startsWith("/api/proactive/") -> return ok(JSONObject().put("ok",true))
                method == "GET" && path.startsWith("/api/v13/auth/status") -> return ok(JSONObject().put("configured",false).put("authenticated",true))
                method == "POST" && path.startsWith("/api/v13/auth/") -> return ok(JSONObject().put("ok",true))
                method == "GET" && path == "/api/v13/proactive" -> return ok(JSONObject().put("insights",JSONArray()))
                method == "GET" && path == "/api/v13/sync/status" -> return ok(JSONObject().put("has_snapshot",false))
                method == "GET" && path == "/api/v13/voice" -> return ok(JSONObject().put("enabled",true).put("rate",1.0).put("pitch",1.0))
                method == "PUT" && path == "/api/v13/voice" -> return ok(JSONObject().put("ok",true))
                method == "GET" && path.startsWith("/api/v13/") -> return ok(JSONArray())
                method == "POST" && path.startsWith("/api/v13/") -> return ok(JSONObject().put("ok",true))
                method == "PUT" && path.startsWith("/api/v13/") -> return ok(JSONObject().put("ok",true))
                method == "PATCH" && path.startsWith("/api/v13/") -> return ok(JSONObject().put("ok",true))
                method == "DELETE" && path.startsWith("/api/v13/") -> return ok(JSONObject().put("ok",true))
                method == "GET" && path.startsWith("/api/v14/") -> return ok(JSONObject().put("tools",JSONArray()).put("plans",JSONArray()).put("audit",JSONArray()).put("permissions",JSONObject()))
                method == "POST" && path.startsWith("/api/v14/") -> return ok(JSONObject().put("ok",true).put("proposal",JSONObject().put("title","Standalone proposal").put("goal",JSONObject(body).optString("goal")).put("steps",JSONArray())))
                method == "PUT" && path.startsWith("/api/v14/") -> return ok(JSONObject().put("ok",true))
                method == "PATCH" && path.startsWith("/api/v14/") -> return ok(JSONObject().put("ok",true))
                method == "DELETE" && path.startsWith("/api/v14/") -> return ok(JSONObject().put("ok",true))
                else -> return Pair(404, JSONObject().put("error","Not found").toString())
            }
        } catch (e: Exception) { return Pair(400, JSONObject().put("error",e.message ?: "Bad request").toString()) }
    }

    private fun chat(o: JSONObject): Pair<Int,String> {
        val pid=o.optString("profile_id","guest"); val chatId=o.optString("chat_id",""); val message=o.optString("message").trim()
        if (message.isEmpty()) return Pair(400, JSONObject().put("error","Message is empty").toString())
        val id=if(chatId.isEmpty()) db.newChat(pid,"New conversation").optString("id") else chatId
        db.addMessage(id,"user",message)
        val reply = cloudChat(pid, message)
        db.addMessage(id,"assistant",reply)
        return ok(JSONObject().put("reply",reply).put("retrieved",db.brain(message,pid)))
    }

    private fun cloudChat(pid:String, message:String): String {
        val prefs=context.getSharedPreferences("smartie_v21", Context.MODE_PRIVATE)
        val key=prefs.getString("openrouter_key","") ?: ""
        if(key.isBlank()) return "I’m ready. Add your OpenRouter API key in Smartie Settings to enable cloud AI. Your chats stay on this phone unless you use a cloud model."
        return try {
            val u=URL("https://openrouter.ai/api/v1/chat/completions")
            val c=u.openConnection() as HttpsURLConnection
            c.requestMethod="POST"; c.connectTimeout=10000; c.readTimeout=60000; c.doOutput=true
            c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer $key")
            c.setRequestProperty("HTTP-Referer","https://studysmart.kabejadrinks.com"); c.setRequestProperty("X-Title","Smartie AI Android")
            val sys="You are Smartie AI, the official AI assistant of StudySmart UG. Help Ugandan Senior 1-Senior 6 learners. Keep explanations clear, practical and age-appropriate. Subjects include Mathematics, Biology, ICT, Agriculture, Geography, Economics and related school work."
            val messages=JSONArray().put(JSONObject().put("role","system").put("content",sys)).put(JSONObject().put("role","user").put("content",message))
            val payload=JSONObject().put("model",prefs.getString("openrouter_model","openrouter/free")).put("messages",messages).put("temperature",0.6)
            c.outputStream.use{it.write(payload.toString().toByteArray())}
            val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
            val raw=stream.bufferedReader().use{it.readText()}; val j=JSONObject(raw)
            if(c.responseCode !in 200..299) "Cloud AI error: ${j.optString("error",raw.take(300))}" else j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: "The model returned no text."
        } catch(e:Exception) { "Cloud AI is unavailable right now. ${e.message ?: "Check your connection and API key."}" }
    }

    private fun parseQuery(q:String):Map<String,String> = q.split('&').filter{it.contains('=')}.associate { val p=it.split('=',limit=2); java.net.URLDecoder.decode(p[0],"UTF-8") to java.net.URLDecoder.decode(p[1],"UTF-8") }
    private fun ok(x:Any):Pair<Int,String> = Pair(200, if(x is String)x else x.toString())
    private fun writeResponse(s:Socket,status:Int,body:String){val out=BufferedWriter(OutputStreamWriter(s.getOutputStream(),Charsets.UTF_8));val msg=when(status){200->"OK";400->"Bad Request";404->"Not Found";else->"Server Error"};val b=body.toByteArray(Charsets.UTF_8);val ct=if(body.trimStart().startsWith("<"))"text/html; charset=utf-8" else "application/json; charset=utf-8";out.write("HTTP/1.1 $status $msg\r\nContent-Type: $ct\r\nContent-Length: ${b.size}\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS\r\nConnection: close\r\n\r\n");out.flush();s.getOutputStream().write(b);s.getOutputStream().flush()}

    private class Store(ctx:Context):SQLiteOpenHelper(ctx,"smartie_v21.db",null,1){
        override fun onCreate(d:SQLiteDatabase){d.execSQL("CREATE TABLE profiles(id TEXT PRIMARY KEY,name TEXT,country TEXT,education TEXT,subjects TEXT,goals TEXT,projects TEXT,style TEXT,extra TEXT)");d.execSQL("CREATE TABLE chats(id TEXT PRIMARY KEY,profile_id TEXT,title TEXT,created_at INTEGER)");d.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id TEXT,role TEXT,content TEXT,created_at INTEGER)");d.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id TEXT,content TEXT,category TEXT,importance TEXT,created_at INTEGER)");d.execSQL("CREATE TABLE projects(id TEXT PRIMARY KEY,profile_id TEXT,name TEXT,description TEXT,status TEXT)");d.execSQL("CREATE TABLE tasks(id TEXT PRIMARY KEY,profile_id TEXT,title TEXT,done INTEGER DEFAULT 0,created_at INTEGER)")}
        override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){}
        private fun profile0(id:String):JSONObject=JSONObject().put("id",id).put("name",if(id=="akram")"Akram" else "Guest").put("country","Uganda").put("education","Senior Secondary").put("subjects","Mathematics, Economics, Geography, ICT").put("goals","").put("projects","StudySmart UG").put("style","clear and practical").put("extra","")
        fun profile(id:String):JSONObject{val c=read("SELECT * FROM profiles WHERE id=?",arrayOf(id));if(!c.moveToFirst()){c.close();val p=profile0(id);saveProfile(id,p);return p};val p=JSONObject().put("id",id);for(k in listOf("name","country","education","subjects","goals","projects","style","extra"))p.put(k,c.getString(c.getColumnIndexOrThrow(k)));c.close();return p}
        fun saveProfile(id:String,p:JSONObject){val db=writableDatabase;db.execSQL("INSERT OR REPLACE INTO profiles VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(id,p.optString("name"),p.optString("country"),p.optString("education"),p.optString("subjects"),p.optString("goals"),p.optString("projects"),p.optString("style"),p.optString("extra")))}
        fun chats(pid:String):JSONArray=rows("SELECT * FROM chats WHERE profile_id=? ORDER BY created_at DESC",arrayOf(pid)){JSONObject().put("id",it.getString(it.getColumnIndexOrThrow("id"))).put("profile_id",pid).put("title",it.getString(it.getColumnIndexOrThrow("title"))).put("created_at",it.getLong(it.getColumnIndexOrThrow("created_at")))}
        fun newChat(pid:String,title:String):JSONObject{val id=UUID.randomUUID().toString();writableDatabase.execSQL("INSERT INTO chats VALUES(?,?,?,?)",arrayOf(id,pid,title,System.currentTimeMillis()));return JSONObject().put("id",id).put("profile_id",pid).put("title",title).put("created_at",System.currentTimeMillis())}
        fun messages(id:String):JSONArray=rows("SELECT * FROM messages WHERE chat_id=? ORDER BY created_at",arrayOf(id)){JSONObject().put("id",it.getLong(it.getColumnIndexOrThrow("id"))).put("chat_id",id).put("role",it.getString(it.getColumnIndexOrThrow("role"))).put("content",it.getString(it.getColumnIndexOrThrow("content"))).put("created_at",it.getLong(it.getColumnIndexOrThrow("created_at")))}
        fun addMessage(chat:String,role:String,content:String){writableDatabase.execSQL("INSERT INTO messages(chat_id,role,content,created_at) VALUES(?,?,?,?)",arrayOf(chat,role,content,System.currentTimeMillis()))}
        fun addMessages(chat:String,o:JSONObject){val a=o.optJSONArray("messages")?:return;for(i in 0 until a.length()){val x=a.optJSONObject(i)?:continue;addMessage(chat,x.optString("role"),x.optString("content"))}}
        fun memories(pid:String):JSONArray=rows("SELECT * FROM memories WHERE profile_id=? ORDER BY created_at DESC",arrayOf(pid)){JSONObject().put("id",it.getLong(it.getColumnIndexOrThrow("id"))).put("profile_id",pid).put("content",it.getString(it.getColumnIndexOrThrow("content"))).put("category",it.getString(it.getColumnIndexOrThrow("category"))).put("importance",it.getString(it.getColumnIndexOrThrow("importance"))).put("created_at",it.getLong(it.getColumnIndexOrThrow("created_at")))}
        fun addMemory(o:JSONObject):JSONObject{val db=writableDatabase;db.execSQL("INSERT INTO memories(profile_id,content,category,importance,created_at) VALUES(?,?,?,?,?)",arrayOf(o.optString("profile_id","guest"),o.optString("content"),o.optString("category","general"),o.optString("importance","long-term"),System.currentTimeMillis()));return o.put("id",db.rawQuery("SELECT last_insert_rowid()",null).use{it.moveToFirst();it.getLong(0)})}
        fun deleteMemory(id:String){writableDatabase.delete("memories","id=?",arrayOf(id))}
        fun forgetMemories(pid:String,q:String){writableDatabase.delete("memories","profile_id=? AND content LIKE ?",arrayOf(pid,"%$q%"))}
        fun projects(pid:String):JSONArray=rows("SELECT * FROM projects WHERE profile_id=?",arrayOf(pid)){JSONObject().put("id",it.getString(it.getColumnIndexOrThrow("id"))).put("profile_id",pid).put("name",it.getString(it.getColumnIndexOrThrow("name"))).put("description",it.getString(it.getColumnIndexOrThrow("description"))).put("status",it.getString(it.getColumnIndexOrThrow("status")))}
        fun addProject(o:JSONObject):JSONObject{val id=UUID.randomUUID().toString();writableDatabase.execSQL("INSERT INTO projects VALUES(?,?,?,?,?)",arrayOf(id,o.optString("profile_id","guest"),o.optString("name"),o.optString("description",""),o.optString("status","active")));return o.put("id",id)}
        fun updateProject(id:String,o:JSONObject):JSONObject{writableDatabase.execSQL("UPDATE projects SET name=?,description=?,status=? WHERE id=?",arrayOf(o.optString("name"),o.optString("description"),o.optString("status"),id));return o.put("id",id)}
        fun deleteProject(id:String){writableDatabase.delete("projects","id=?",arrayOf(id))}
        fun tasks(pid:String):JSONArray=rows("SELECT * FROM tasks WHERE profile_id=? ORDER BY created_at DESC",arrayOf(pid)){JSONObject().put("id",it.getString(it.getColumnIndexOrThrow("id"))).put("profile_id",pid).put("title",it.getString(it.getColumnIndexOrThrow("title"))).put("done",it.getInt(it.getColumnIndexOrThrow("done"))==1).put("created_at",it.getLong(it.getColumnIndexOrThrow("created_at")))}
        fun addTask(o:JSONObject):JSONObject{val id=UUID.randomUUID().toString();writableDatabase.execSQL("INSERT INTO tasks VALUES(?,?,?,?,?)",arrayOf(id,o.optString("profile_id","guest"),o.optString("title"),if(o.optBoolean("done"))1 else 0,System.currentTimeMillis()));return o.put("id",id).put("done",false)}
        fun updateTask(id:String,o:JSONObject):JSONObject{if(o.has("done"))writableDatabase.execSQL("UPDATE tasks SET done=? WHERE id=?",arrayOf(if(o.optBoolean("done"))1 else 0,id));if(o.has("title"))writableDatabase.execSQL("UPDATE tasks SET title=? WHERE id=?",arrayOf(o.optString("title"),id));return o.put("id",id)}
        fun deleteTask(id:String){writableDatabase.delete("tasks","id=?",arrayOf(id))}
        fun brain(q:String,pid:String):JSONObject{return JSONObject().put("memories",memories(pid)).put("projects",projects(pid)).put("tasks",tasks(pid)).put("messages",JSONArray()).put("context","Relevant local context for: $q")}
        private fun read(sql:String,args:Array<String>):android.database.Cursor=writableDatabase.rawQuery(sql,args)
        private fun rows(sql:String,args:Array<String>,make:(android.database.Cursor)->JSONObject):JSONArray{val a=JSONArray();val c=read(sql,args);while(c.moveToNext())a.put(make(c));c.close();return a}
    }
}
