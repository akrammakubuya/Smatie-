# Smartie Personal AI V20

V20 adds a real local-model download and management layer on top of V19.

## Core behavior
- Device capability and storage checks are used before downloads.
- Users explicitly approve every model download.
- Multi-GB models are allowed when the device has enough storage/resources.
- Mobile-data downloads above 1 GB receive a confirmation prompt.
- Android uses WorkManager for background model downloads.
- Downloads support interrupted-file continuation when the HTTP source supports Range requests.
- Optional SHA-256 verification is performed after download.
- Verified downloads are marked complete only after the worker finishes.
- Model profiles are stored locally and can be removed.
- The existing V19 runtime verification remains separate: a downloaded file is not automatically treated as an inference-capable runtime/model.

## Model sources
V20 intentionally does not ship with invented model URLs. Add a direct HTTPS model-file URL from a provider you trust. A future catalog/provider integration can populate these automatically after provider verification.

## Android
- Version code: 20
- Version name: 20.0.0
- Min SDK: 26
- Target SDK: 35
- Added foreground-service permissions for long-running model downloads.


## Safety and data controls
- No model is downloaded automatically.
- HTTPS direct model URLs are required by the V20 UI.
- The user confirms large downloads, especially on cellular data.
- Storage is checked before queuing the download.
- Optional SHA-256 verification prevents a completed download from being treated as verified when its digest does not match.
- Download completion does not equal runtime readiness; V19's runtime probe remains the activation gate.
