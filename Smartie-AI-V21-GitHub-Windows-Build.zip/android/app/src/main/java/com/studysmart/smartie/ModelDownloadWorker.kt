package com.studysmart.smartie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Environment
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class ModelDownloadWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    companion object { const val KEY_ID="id"; const val KEY_URL="url"; const val KEY_SHA="sha256"; const val KEY_NAME="name"; const val KEY_FILE="file"; const val KEY_PROGRESS="progress" }
    private val prefs by lazy { applicationContext.getSharedPreferences("smartie_v20_downloads", Context.MODE_PRIVATE) }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id=inputData.getString(KEY_ID) ?: return@withContext Result.failure(workDataOf("error" to "Missing model id"))
        val url=inputData.getString(KEY_URL) ?: return@withContext Result.failure(workDataOf("error" to "Missing model URL"))
        val expected=inputData.getString(KEY_SHA)?.lowercase()?.trim().orEmpty()
        val name=inputData.getString(KEY_NAME)?.ifBlank { "model-$id" } ?: "model-$id"
        val dir=File(applicationContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"models").apply{mkdirs()}
        val safe=name.replace(Regex("[^A-Za-z0-9._-]"),"_")
        val file=File(dir, safe)
        prefs.edit().putString("$id.file",file.absolutePath).putString("$id.status","downloading").apply()
        setForeground(createForegroundInfo(id, name, 0))
        var existing=if(file.exists())file.length() else 0L
        val conn=(URL(url).openConnection() as HttpURLConnection).apply{
            connectTimeout=15000; readTimeout=30000; instanceFollowRedirects=true
            if(existing>0) setRequestProperty("Range","bytes=$existing-")
        }
        try {
            conn.connect()
            val code=conn.responseCode
            if(existing>0 && code==416){ file.delete(); existing=0 }
            if(existing>0 && code==200){ file.delete(); existing=0 }
            if(existing==0L && code !in 200..299) return@withContext Result.failure(workDataOf("error" to "HTTP $code"))
            if(existing>0 && code!=206) return@withContext Result.failure(workDataOf("error" to "Server did not support resume (HTTP $code)"))
            val total=if(code==206) existing + conn.contentLengthLong.coerceAtLeast(0) else conn.contentLengthLong.coerceAtLeast(0)
            conn.inputStream.use { input ->
                RandomAccessFile(file,"rw").use { out ->
                    out.seek(existing)
                    val buf=ByteArray(1024*1024)
                    var done=existing
                    while(true){
                        ensureActive()
                        val n=input.read(buf)
                        if(n<0)break
                        out.write(buf,0,n); done+=n
                        val pct=if(total>0) ((done*100)/total).toInt().coerceIn(0,100) else -1
                        prefs.edit().putLong("$id.bytes",done).putLong("$id.total",total).apply()
                        setProgress(workDataOf(KEY_PROGRESS to pct, "bytes" to done, "total" to total))
                        setForeground(createForegroundInfo(id,name,pct))
                    }
                }
            }
            if(expected.isNotBlank()){
                val actual=sha256(file)
                if(!MessageDigest.isEqual(actual.toByteArray(),expected.toByteArray())){
                    file.delete(); prefs.edit().putString("$id.status","verification_failed").apply()
                    return@withContext Result.failure(workDataOf("error" to "SHA-256 verification failed"))
                }
            }
            prefs.edit().putString("$id.status","verified").putString("$id.file",file.absolutePath).apply()
            setProgress(workDataOf(KEY_PROGRESS to 100,"bytes" to file.length(),"total" to file.length()))
            Result.success(workDataOf("file" to file.absolutePath,"verified" to true))
        } catch(e: Exception){
            prefs.edit().putString("$id.status", if(isStopped) "paused_or_cancelled" else "failed").apply()
            if(isStopped) Result.failure(workDataOf("error" to "Download stopped")) else Result.retry()
        } finally { conn.disconnect() }
    }
    private fun sha256(f:File):String{
        val md=MessageDigest.getInstance("SHA-256")
        f.inputStream().use{input->val b=ByteArray(1024*1024);while(true){val n=input.read(b);if(n<0)break;md.update(b,0,n)}}
        return md.digest().joinToString(""){ "%02x".format(it) }
    }
    private fun createForegroundInfo(id:String,name:String,pct:Int):ForegroundInfo{
        val channel="smartie_model_downloads"
        val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Model downloads",NotificationManager.IMPORTANCE_LOW))
        val n=Notification.Builder(applicationContext,channel).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Smartie model: $name").setContentText(if(pct>=0)"Downloading $pct%" else "Downloading…").setOngoing(true).setProgress(100,pct.coerceAtLeast(0),pct<0).build()
        return ForegroundInfo((id.hashCode() and 0x7fffffff),n)
    }
}
