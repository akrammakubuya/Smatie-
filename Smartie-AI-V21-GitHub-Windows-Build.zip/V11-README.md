# Smartie Personal Phone Deploy V11

V11 adds the Automation & Workflow Engine.

Features:
- Recurring Smartie routines: hourly, daily, weekdays, weekly.
- Routine prompts and internal progress snapshots.
- Manual Run Now.
- Pause/enable and delete routines.
- Recent workflow run history.
- Lightweight local scheduler that checks due routines every minute while the server is running.
- No automatic external side effects. The engine does not send messages, spend money, modify outside accounts, or perform external actions.

V10 Voice, V9 Knowledge, V8 Proactive, V7 Actions, V6 Brain, V5 Memory and earlier features remain included.

Phone limitation:
The local scheduler can only run while the Smartie server process is running. It is not a replacement for Android's OS-level alarm/notification service.
