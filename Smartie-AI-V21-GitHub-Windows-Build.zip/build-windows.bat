@echo off
setlocal
cd /d "%~dp0"
echo === Smartie AI V21 Windows Desktop Builder ===
echo.
where node >nul 2>nul || (echo Node.js is required. Install Node.js 20+ first.&pause&exit /b 1)
where npm >nul 2>nul || (echo npm is required.&pause&exit /b 1)
node -e "const v=process.versions.node.split('.')[0]; if(Number(v)<20) process.exit(1)" || (echo Node.js 20+ is required.&pause&exit /b 1)
echo Installing or verifying dependencies...
call npm install --include=dev
if errorlevel 1 (echo npm install failed.&pause&exit /b 1)
echo Rebuilding native modules for Electron...
call npx electron-builder install-app-deps
if errorlevel 1 (echo Native module rebuild failed.&pause&exit /b 1)
echo Building Smartie AI V21...
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm run dist
if errorlevel 1 (echo Build failed.&pause&exit /b 1)
echo.
echo Build complete. Check the dist folder for the installer and portable EXE.
pause
