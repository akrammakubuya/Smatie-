// Smartie V21 desktop preload reserved for future native integrations.
// The web UI remains isolated from Node/Electron APIs.
