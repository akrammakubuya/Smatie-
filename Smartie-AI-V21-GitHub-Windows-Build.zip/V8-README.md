# Smartie Personal Phone Deploy V8

V8 adds the Proactive Intelligence Engine.

## What changed
- Proactive insight generation from tasks, action plans and recent activity.
- Detects overdue tasks.
- Suggests a next move when many tasks are open.
- Highlights the next unfinished action-plan step.
- Suggests capturing a goal when recent activity exists but no plan/task is active.
- Dismissable suggestions.
- Manual refresh.
- All suggestions remain local to the active profile and do not perform external side effects automatically.

V7 features remain included.
