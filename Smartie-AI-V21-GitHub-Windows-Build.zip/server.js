require("dotenv").config();
const express = require("express");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_TITLE = process.env.APP_TITLE || "Smartie AI";
const dbDir = process.env.SMARTIE_DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(path.join(dbDir, "smartie-v6.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  country TEXT DEFAULT '',
  education TEXT DEFAULT '',
  subjects TEXT DEFAULT '',
  goals TEXT DEFAULT '',
  projects TEXT DEFAULT '',
  style TEXT DEFAULT '',
  extra TEXT DEFAULT '',
  is_akram INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  title TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  chat_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(chat_id) REFERENCES chats(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS memories (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  category TEXT NOT NULL,
  importance TEXT NOT NULL,
  content TEXT NOT NULL,
  source_chat_id TEXT,
  source_message_id TEXT,
  confidence REAL DEFAULT 1,
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  project_id TEXT,
  title TEXT NOT NULL,
  due TEXT DEFAULT '',
  done INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS action_plans (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  title TEXT NOT NULL,
  goal TEXT DEFAULT '',
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS action_steps (
  id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  title TEXT NOT NULL,
  details TEXT DEFAULT '',
  due TEXT DEFAULT '',
  done INTEGER DEFAULT 0,
  position INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(plan_id) REFERENCES action_plans(id) ON DELETE CASCADE,
  FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
  message_id UNINDEXED, chat_id UNINDEXED, profile_id UNINDEXED, content,
  tokenize='unicode61'
);
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
  memory_id UNINDEXED, profile_id UNINDEXED, content,
  tokenize='unicode61'
);
`);

function now(){return new Date().toISOString()}
function uid(prefix){return prefix+"_"+crypto.randomUUID()}
function profile(id){return db.prepare("SELECT * FROM profiles WHERE id=?").get(id)}
function ensureProfile(p){
  if(!profile(p.id)){
    const t=now();
    db.prepare(`INSERT INTO profiles
      (id,name,country,education,subjects,goals,projects,style,extra,is_akram,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      p.id,p.name||"Guest",p.country||"",p.education||"",p.subjects||"",
      p.goals||"",p.projects||"",p.style||"",p.extra||"",p.is_akram?1:0,t,t
    );
  }
}
ensureProfile({id:"akram",name:"Akram",is_akram:1});
ensureProfile({id:"guest",name:"Guest",is_akram:0});

function curriculumContext(){
  const dir=path.join(__dirname,"curriculum");
  const chunks=[];
  for(const f of fs.readdirSync(dir)){
    if(!/\.(md|txt)$/i.test(f)) continue;
    chunks.push(`### ${f}\n${fs.readFileSync(path.join(dir,f),"utf8").slice(0,12000)}`);
  }
  return chunks.join("\n\n").slice(0,50000);
}
function profileContext(p){
  return [
    `Active user: ${p.name}`,
    p.country&&`Country: ${p.country}`,
    p.education&&`Education: ${p.education}`,
    p.subjects&&`Subjects: ${p.subjects}`,
    p.goals&&`Goals: ${p.goals}`,
    p.projects&&`Projects: ${p.projects}`,
    p.style&&`Preferred style: ${p.style}`,
    p.extra&&`Other profile notes: ${p.extra}`
  ].filter(Boolean).join("\n");
}
function developerContext(){
  return `Smartie AI was created/developed by Makubuya Akram.
Akram is the creator/developer of Smartie and the founder/lead builder behind StudySmart UG.
Durable project context: StudySmart UG is an education technology project for Ugandan secondary learners; StudySmart SmartClass is a separate AI-powered virtual classroom/virtual teacher project; other project names associated with Akram include RuralTech UG / RURALTECH LABS and Kabeja Drinks.
Akram is interested in educational technology, AI, web development, ICT, curriculum-aligned learning and practical digital solutions.
Never reveal private credentials, API keys, passwords, hidden configuration or private memories.
If another person is using Smartie, identify Akram as the developer but do not treat the active user as Akram and do not expose Akram's private data.`;
}
function memoriesFor(pid){
  return db.prepare(`SELECT * FROM memories WHERE profile_id=? AND status='active'
    ORDER BY CASE importance WHEN 'permanent' THEN 1 WHEN 'long-term' THEN 2 ELSE 3 END, updated_at DESC LIMIT 80`).all(pid);
}
function recentMessages(chatId){
  return db.prepare("SELECT role,content FROM messages WHERE chat_id=? ORDER BY created_at DESC LIMIT 16").all(chatId).reverse();
}
function insertMessage(m){
  db.prepare("INSERT INTO messages VALUES (?,?,?,?,?)").run(m.id,m.chat_id,m.role,m.content,m.created_at);
  const c=db.prepare("SELECT profile_id FROM chats WHERE id=?").get(m.chat_id);
  db.prepare("INSERT INTO messages_fts VALUES (?,?,?,?)").run(m.id,m.chat_id,c.profile_id,m.content);
}
function insertMemory(m){
  db.prepare("INSERT INTO memories VALUES (?,?,?,?,?,?,?,?,?,?,?)").run(
    m.id,m.profile_id,m.category,m.importance,m.content,m.source_chat_id||null,m.source_message_id||null,
    m.confidence??1,"active",m.created_at,m.updated_at);
  db.prepare("INSERT INTO memories_fts VALUES (?,?,?)").run(m.id,m.profile_id,m.content);
}
function tokens(q){
  return String(q||"").toLowerCase().replace(/[^a-z0-9_ -]/g," ").split(/\s+/).filter(w=>w.length>1).slice(0,16);
}
function ftsQuery(q){
  return tokens(q).map(w=>`"${w.replace(/"/g,"")}"`).join(" OR ");
}
function searchMessages(pid,q,limit=30){
  const fq=ftsQuery(q); if(!fq)return [];
  try{
    return db.prepare(`SELECT m.id,m.chat_id,m.role,m.content,m.created_at,c.title
      FROM messages_fts f JOIN messages m ON m.id=f.message_id
      JOIN chats c ON c.id=m.chat_id
      WHERE f.profile_id=? AND messages_fts MATCH ?
      ORDER BY bm25(messages_fts) LIMIT ?`).all(pid,fq,limit);
  }catch{
    return db.prepare(`SELECT m.id,m.chat_id,m.role,m.content,m.created_at,c.title
      FROM messages m JOIN chats c ON c.id=m.chat_id
      WHERE c.profile_id=? AND m.content LIKE ? ORDER BY m.created_at DESC LIMIT ?`)
      .all(pid,"%"+String(q)+"%",limit);
  }
}
function searchMemories(pid,q,limit=20){
  const fq=ftsQuery(q); if(!fq)return [];
  try{
    return db.prepare(`SELECT x.* FROM memories_fts f JOIN memories x ON x.id=f.memory_id
      WHERE f.profile_id=? AND x.status='active' AND memories_fts MATCH ?
      ORDER BY bm25(memories_fts) LIMIT ?`).all(pid,fq,limit);
  }catch{
    return db.prepare(`SELECT * FROM memories WHERE profile_id=? AND status='active' AND content LIKE ?
      ORDER BY updated_at DESC LIMIT ?`).all(pid,"%"+String(q)+"%",limit);
  }
}
function searchProjects(pid,q,limit=12){
  const ts=tokens(q); if(!ts.length)return [];
  const rows=db.prepare("SELECT * FROM projects WHERE profile_id=? ORDER BY updated_at DESC").all(pid);
  return rows.map(x=>({x,score:ts.reduce((s,t)=>s+(x.name+" "+x.description).toLowerCase().includes(t)?2:0,0)}))
    .filter(o=>o.score>0).sort((a,b)=>b.score-a.score).slice(0,limit).map(o=>o.x);
}
function searchTasks(pid,q,limit=15){
  const ts=tokens(q); if(!ts.length)return [];
  const rows=db.prepare("SELECT * FROM tasks WHERE profile_id=? ORDER BY updated_at DESC").all(pid);
  return rows.map(x=>({x,score:ts.reduce((s,t)=>s+(x.title.toLowerCase().includes(t)?2:0),0)}))
    .filter(o=>o.score>0).sort((a,b)=>b.score-a.score).slice(0,limit).map(o=>o.x);
}
function brainSearch(pid,q){
  const messages=searchMessages(pid,q,24);
  const memories=searchMemories(pid,q,16);
  const projects=searchProjects(pid,q,10);
  const tasks=searchTasks(pid,q,12);
  return {query:q,messages,memories,projects,tasks};
}
function brainContext(b){
  const parts=[];
  if(b.memories.length) parts.push("RELEVANT SAVED MEMORIES:\n"+b.memories.map(x=>`- ${x.content}`).join("\n"));
  if(b.projects.length) parts.push("RELEVANT PROJECTS:\n"+b.projects.map(x=>`- ${x.name}: ${x.description} [${x.status}]`).join("\n"));
  if(b.tasks.length) parts.push("RELEVANT TASKS:\n"+b.tasks.map(x=>`- ${x.title}${x.done?" [done]":""}${x.due?" (due "+x.due+")":""}`).join("\n"));
  if(b.messages.length) parts.push("RELEVANT PAST CONVERSATION:\n"+b.messages.slice(0,14).map(x=>`- ${x.title} | ${x.created_at}\n  ${x.role}: ${x.content.slice(0,700)}`).join("\n"));
  return parts.join("\n\n").slice(0,28000) || "No relevant older context was retrieved.";
}
function titleGuess(text){
  const s=String(text||"").replace(/\s+/g," ").trim();
  if(!s)return "New conversation";
  return s.length>55?s.slice(0,55)+"…":s;
}

app.use(express.json({limit:"2mb"}));

/* ================= V13 FOUNDATION: SECURITY, SYNC, RESEARCH, GRAPH, INTEGRATIONS ================= */
db.exec(`
CREATE TABLE IF NOT EXISTS proactive_insights (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id TEXT NOT NULL, type TEXT NOT NULL,
 title TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, dismissed INTEGER DEFAULT 0,
 UNIQUE(profile_id,type,title)
);
CREATE TABLE IF NOT EXISTS knowledge_documents (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, name TEXT NOT NULL, mime TEXT DEFAULT 'text/plain',
 content TEXT NOT NULL, size INTEGER DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(document_id UNINDEXED,profile_id UNINDEXED,name,content,tokenize='unicode61');
CREATE TABLE IF NOT EXISTS voice_settings (
 profile_id TEXT PRIMARY KEY, enabled INTEGER DEFAULT 1, rate REAL DEFAULT 1, pitch REAL DEFAULT 1, voice_name TEXT DEFAULT '',
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS routines (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, title TEXT NOT NULL, prompt TEXT NOT NULL,
 frequency TEXT NOT NULL, next_run TEXT NOT NULL, enabled INTEGER DEFAULT 1, last_run TEXT DEFAULT '',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS workflow_runs (
 id TEXT PRIMARY KEY, routine_id TEXT NOT NULL, profile_id TEXT NOT NULL, started_at TEXT NOT NULL,
 finished_at TEXT NOT NULL, result TEXT DEFAULT '', FOREIGN KEY(routine_id) REFERENCES routines(id) ON DELETE CASCADE,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS reminders (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, title TEXT NOT NULL, body TEXT DEFAULT '', remind_at TEXT NOT NULL,
 repeat TEXT DEFAULT 'none', enabled INTEGER DEFAULT 1, delivered INTEGER DEFAULT 0, created_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS graph_nodes (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, kind TEXT NOT NULL, label TEXT NOT NULL, ref_id TEXT DEFAULT '',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(profile_id,kind,ref_id,label)
);
CREATE TABLE IF NOT EXISTS graph_edges (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, from_id TEXT NOT NULL, to_id TEXT NOT NULL, relation TEXT NOT NULL,
 created_at TEXT NOT NULL, UNIQUE(profile_id,from_id,to_id,relation), FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS v13_accounts (
 profile_id TEXT PRIMARY KEY, password_hash TEXT NOT NULL, salt TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS v13_sessions (
 token_hash TEXT PRIMARY KEY, profile_id TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS sync_snapshots (
 profile_id TEXT PRIMARY KEY, device_token_hash TEXT NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS v13_preferences (
 profile_id TEXT PRIMARY KEY, theme TEXT DEFAULT 'system', response_style TEXT DEFAULT 'balanced',
 detail_level TEXT DEFAULT 'medium', proactive INTEGER DEFAULT 1, voice INTEGER DEFAULT 1, research INTEGER DEFAULT 1,
 updated_at TEXT NOT NULL, FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS integrations (
 id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL, config TEXT DEFAULT '{}',
 enabled INTEGER DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE
);
`);

function parseCookies(req){const out={};for(const part of String(req.headers.cookie||'').split(';')){const i=part.indexOf('=');if(i>0)out[part.slice(0,i).trim()]=decodeURIComponent(part.slice(i+1).trim())}return out}
function hashPassword(password,salt){return crypto.scryptSync(String(password),Buffer.from(salt,'hex'),32).toString('hex')}
function sessionFor(req){const raw=parseCookies(req).smartie_session;if(!raw)return null;const h=crypto.createHash('sha256').update(raw).digest('hex');const x=db.prepare('SELECT * FROM v13_sessions WHERE token_hash=? AND expires_at>?').get(h,now());return x||null}
function v13Auth(req,res,next){const s=sessionFor(req);if(!s)return res.status(401).json({error:'V13 login required'});req.v13Session=s;next()}
const authAttempts=new Map();
function allowLogin(key){const a=authAttempts.get(key)||{n:0,at:Date.now()};if(Date.now()-a.at>60000){a.n=0;a.at=Date.now()}if(a.n>=8)return false;a.n++;authAttempts.set(key,a);return true}
function setSession(res,pid){const token=crypto.randomBytes(32).toString('hex');const h=crypto.createHash('sha256').update(token).digest('hex');const exp=new Date(Date.now()+1000*60*60*24*30).toISOString();db.prepare('INSERT INTO v13_sessions VALUES (?,?,?,?)').run(h,pid,exp,now());res.setHeader('Set-Cookie',`smartie_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`)}
function requireOwn(req,pid){return req.v13Session && req.v13Session.profile_id===String(pid)}
function nextReminderTime(base,repeat){const d=new Date(base);if(repeat==='daily')d.setDate(d.getDate()+1);else if(repeat==='weekdays'){d.setDate(d.getDate()+1);while([0,6].includes(d.getDay()))d.setDate(d.getDate()+1)}else if(repeat==='weekly')d.setDate(d.getDate()+7);else return null;return d.toISOString()}
function routineNextRun(from,frequency){const d=new Date(from);if(frequency==='hourly')d.setHours(d.getHours()+1);else if(frequency==='daily')d.setDate(d.getDate()+1);else if(frequency==='weekly')d.setDate(d.getDate()+7);else {d.setDate(d.getDate()+1);while([0,6].includes(d.getDay()))d.setDate(d.getDate()+1)}return d.toISOString()}
function knowledgeSync(id){db.prepare('DELETE FROM knowledge_fts WHERE document_id=?').run(id);const x=db.prepare('SELECT id,profile_id,name,content FROM knowledge_documents WHERE id=?').get(id);if(x)db.prepare('INSERT INTO knowledge_fts VALUES (?,?,?,?)').run(x.id,x.profile_id,x.name,x.content)}
function knowledgeResults(pid,q,limit=20){const fq=ftsQuery(q);if(!fq)return[];try{return db.prepare(`SELECT d.id,d.profile_id,d.name,d.mime,d.size,d.created_at,d.updated_at,snippet(knowledge_fts,3,'','', '…',18) snippet FROM knowledge_fts JOIN knowledge_documents d ON d.id=knowledge_fts.document_id WHERE knowledge_fts.profile_id=? AND knowledge_fts MATCH ? ORDER BY bm25(knowledge_fts) LIMIT ?`).all(pid,fq,limit)}catch{return db.prepare('SELECT id,profile_id,name,mime,size,created_at,updated_at,substr(content,1,500) snippet FROM knowledge_documents WHERE profile_id=? AND content LIKE ? ORDER BY updated_at DESC LIMIT ?').all(pid,'%'+q+'%',limit)}}
function buildProactive(pid){const out=[];const overdue=db.prepare("SELECT COUNT(*) n FROM tasks WHERE profile_id=? AND done=0 AND due<>'' AND due < ?").get(pid,now()).n;if(overdue)out.push({type:'overdue',title:'Overdue tasks need attention',body:`You have ${overdue} unfinished task(s) whose due date has passed.`});const open=db.prepare('SELECT COUNT(*) n FROM tasks WHERE profile_id=? AND done=0').get(pid).n;if(open>=5)out.push({type:'task_load',title:'Your task list is getting crowded',body:`There are ${open} open tasks. Consider choosing one next action instead of juggling all of them.`});const steps=db.prepare("SELECT COUNT(*) n FROM action_steps WHERE profile_id=? AND done=0").get(pid).n;if(steps>=3)out.push({type:'plan_steps',title:'Action-plan steps are waiting',body:`You have ${steps} unfinished plan step(s). Review the smallest useful next step.`});return out}
function refreshProactive(pid){const suggestions=buildProactive(pid),t=now();for(const x of suggestions){db.prepare('INSERT OR IGNORE INTO proactive_insights(profile_id,type,title,body,created_at,dismissed) VALUES (?,?,?,?,?,0)').run(pid,x.type,x.title,x.body,t)}return db.prepare('SELECT * FROM proactive_insights WHERE profile_id=? AND dismissed=0 ORDER BY created_at DESC').all(pid)}
function graphRebuild(pid){const t=now();const tx=db.transaction(()=>{db.prepare('DELETE FROM graph_edges WHERE profile_id=?').run(pid);db.prepare('DELETE FROM graph_nodes WHERE profile_id=?').run(pid);const add=db.prepare('INSERT OR IGNORE INTO graph_nodes(id,profile_id,kind,label,ref_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');const edge=db.prepare('INSERT OR IGNORE INTO graph_edges(id,profile_id,from_id,to_id,relation,created_at) VALUES (?,?,?,?,?,?)');const profileNode='gn_profile_'+pid;add.run(profileNode,pid,'profile',profile(pid).name,pid,t,t);for(const p of db.prepare('SELECT * FROM projects WHERE profile_id=?').all(pid)){const id='gn_'+p.id;add.run(id,pid,'project',p.name,p.id,t,t);edge.run(uid('edge'),pid,profileNode,id,'has project',t)}for(const m of db.prepare("SELECT * FROM memories WHERE profile_id=? AND status='active'").all(pid)){const id='gn_'+m.id;add.run(id,pid,'memory',m.content.slice(0,100),m.id,t,t);edge.run(uid('edge'),pid,profileNode,id,'knows',t)}for(const task of db.prepare('SELECT * FROM tasks WHERE profile_id=?').all(pid)){const id='gn_'+task.id;add.run(id,pid,'task',task.title,task.id,t,t);edge.run(uid('edge'),pid,profileNode,id,task.done?'completed task':'open task',t);if(task.project_id){const target='gn_'+task.project_id;if(db.prepare('SELECT 1 FROM graph_nodes WHERE id=?').get(target))edge.run(uid('edge'),pid,target,id,'has task',t)}}});tx()}

app.get('/api/v13/health',(req,res)=>res.json({ok:true,version:'v14',features:['security','sync','research','knowledge','graph','integrations','personalization','notifications','automation','voice']}));
app.post('/api/v13/auth/setup',(req,res)=>{const p=profile(req.body.profile_id),pw=String(req.body.password||'');if(!p)return res.status(404).json({error:'Profile not found'});if(pw.length<8)return res.status(400).json({error:'Use at least 8 characters'});if(db.prepare('SELECT 1 FROM v13_accounts WHERE profile_id=?').get(p.id))return res.status(409).json({error:'Password already set'});const salt=crypto.randomBytes(16).toString('hex');db.prepare('INSERT INTO v13_accounts VALUES (?,?,?,?)').run(p.id,hashPassword(pw,salt),salt,now());setSession(res,p.id);res.json({ok:true,profile_id:p.id})});
app.post('/api/v13/auth/login',(req,res)=>{const p=profile(req.body.profile_id),pw=String(req.body.password||'');if(!p)return res.status(404).json({error:'Profile not found'});if(!allowLogin(req.ip||'unknown'))return res.status(429).json({error:'Too many login attempts. Try again later.'});const a=db.prepare('SELECT * FROM v13_accounts WHERE profile_id=?').get(p.id);if(!a||hashPassword(pw,a.salt)!==a.password_hash)return res.status(401).json({error:'Incorrect password'});setSession(res,p.id);res.json({ok:true,profile_id:p.id})});
app.post('/api/v13/auth/logout',(req,res)=>{const s=sessionFor(req);if(s)db.prepare('DELETE FROM v13_sessions WHERE token_hash=?').run(crypto.createHash('sha256').update(parseCookies(req).smartie_session).digest('hex'));res.setHeader('Set-Cookie','smartie_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true})});
app.get('/api/v13/auth/status',(req,res)=>{const p=profile(req.query.profile_id);if(!p)return res.status(404).json({error:'Profile not found'});res.json({configured:!!db.prepare('SELECT 1 FROM v13_accounts WHERE profile_id=?').get(p.id),authenticated:!!(sessionFor(req)?.profile_id===p.id)})});
app.use('/api/v13',v13Auth);

app.get('/api/v13/me',(req,res)=>res.json({profile:profile(req.v13Session.profile_id)}));
app.get('/api/v13/preferences',(req,res)=>{let x=db.prepare('SELECT * FROM v13_preferences WHERE profile_id=?').get(req.v13Session.profile_id);if(!x){x={profile_id:req.v13Session.profile_id,theme:'system',response_style:'balanced',detail_level:'medium',proactive:1,voice:1,research:1,updated_at:now()};db.prepare('INSERT INTO v13_preferences VALUES (?,?,?,?,?,?,?,?)').run(Object.values(x))}res.json(x)});
app.put('/api/v13/preferences',(req,res)=>{const pid=req.v13Session.profile_id,t=now();db.prepare(`INSERT INTO v13_preferences(profile_id,theme,response_style,detail_level,proactive,voice,research,updated_at) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET theme=excluded.theme,response_style=excluded.response_style,detail_level=excluded.detail_level,proactive=excluded.proactive,voice=excluded.voice,research=excluded.research,updated_at=excluded.updated_at`).run(pid,req.body.theme||'system',req.body.response_style||'balanced',req.body.detail_level||'medium',req.body.proactive===false?0:1,req.body.voice===false?0:1,req.body.research===false?0:1,t);res.json(db.prepare('SELECT * FROM v13_preferences WHERE profile_id=?').get(pid))});

app.get('/api/v13/proactive',(req,res)=>res.json({insights:refreshProactive(req.v13Session.profile_id)}));
app.post('/api/v13/proactive/:id/dismiss',(req,res)=>{db.prepare('UPDATE proactive_insights SET dismissed=1 WHERE id=? AND profile_id=?').run(req.params.id,req.v13Session.profile_id);res.json({ok:true})});
app.post('/api/v13/proactive/refresh',(req,res)=>res.json({insights:refreshProactive(req.v13Session.profile_id)}));

app.get('/api/v13/knowledge',(req,res)=>res.json(db.prepare('SELECT id,name,mime,size,created_at,updated_at FROM knowledge_documents WHERE profile_id=? ORDER BY updated_at DESC').all(req.v13Session.profile_id)));
app.get('/api/v13/knowledge/search',(req,res)=>res.json(knowledgeResults(req.v13Session.profile_id,String(req.query.q||''),Number(req.query.limit||20))));
app.get('/api/v13/knowledge/:id',(req,res)=>{const x=db.prepare('SELECT * FROM knowledge_documents WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!x)return res.status(404).json({error:'Document not found'});res.json(x)});
app.post('/api/v13/knowledge',(req,res)=>{const content=String(req.body.content||'');if(!content)return res.status(400).json({error:'Content required'});const t=now(),x={id:uid('doc'),profile_id:req.v13Session.profile_id,name:String(req.body.name||'Untitled').slice(0,180),mime:String(req.body.mime||'text/plain'),content, size:Buffer.byteLength(content),created_at:t,updated_at:t};db.prepare('INSERT INTO knowledge_documents VALUES (?,?,?,?,?,?,?,?)').run(x.id,x.profile_id,x.name,x.mime,x.content,x.size,x.created_at,x.updated_at);knowledgeSync(x.id);res.json(x)});
app.delete('/api/v13/knowledge/:id',(req,res)=>{db.prepare('DELETE FROM knowledge_documents WHERE id=? AND profile_id=?').run(req.params.id,req.v13Session.profile_id);db.prepare('DELETE FROM knowledge_fts WHERE document_id=?').run(req.params.id);res.json({ok:true})});

app.get('/api/v13/graph',(req,res)=>{const pid=req.v13Session.profile_id;if(!db.prepare('SELECT 1 FROM graph_nodes WHERE profile_id=? LIMIT 1').get(pid))graphRebuild(pid);res.json({nodes:db.prepare('SELECT * FROM graph_nodes WHERE profile_id=? ORDER BY kind,label').all(pid),edges:db.prepare('SELECT * FROM graph_edges WHERE profile_id=?').all(pid)})});
app.post('/api/v13/graph/rebuild',(req,res)=>{graphRebuild(req.v13Session.profile_id);res.json({ok:true})});
app.post('/api/v13/graph/edge',(req,res)=>{const pid=req.v13Session.profile_id;if(!db.prepare('SELECT 1 FROM graph_nodes WHERE id=? AND profile_id=?').get(req.body.from_id,pid)||!db.prepare('SELECT 1 FROM graph_nodes WHERE id=? AND profile_id=?').get(req.body.to_id,pid))return res.status(400).json({error:'Both nodes must belong to your profile'});const e={id:uid('edge'),profile_id:pid,from_id:req.body.from_id,to_id:req.body.to_id,relation:String(req.body.relation||'related to').slice(0,80),created_at:now()};db.prepare('INSERT OR IGNORE INTO graph_edges VALUES (?,?,?,?,?,?)').run(e.id,e.profile_id,e.from_id,e.to_id,e.relation,e.created_at);res.json(e)});

app.get('/api/v13/research',(req,res)=>{
  if(req.query.q===undefined)return res.status(400).json({error:'Query required'});
  const q=String(req.query.q||'').trim().slice(0,300);if(!q)return res.status(400).json({error:'Query required'});
  const url='https://html.duckduckgo.com/html/?q='+encodeURIComponent(q);
  fetch(url,{headers:{'User-Agent':'SmartieAI/14 (research)'}}).then(r=>r.text()).then(html=>{const results=[];const re=/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;let m;while((m=re.exec(html))&&results.length<8){const title=m[2].replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&#x27;/g,"'").replace(/&quot;/g,'"').trim();let link=m[1];const u=link.match(/uddg=([^&]+)/);if(u)try{link=decodeURIComponent(u[1])}catch{}if(/^https?:\/\//.test(link))results.push({title,url:link})}res.json({query:q,results,source:'DuckDuckGo HTML results',note:'Search results are unverified web sources. Check important claims against primary sources.'})}).catch(e=>res.status(502).json({error:'Research request failed',detail:e.message}));
});
app.get('/api/v13/research/fetch',(req,res)=>{const url=String(req.query.url||'');if(!/^https?:\/\//i.test(url))return res.status(400).json({error:'Valid http(s) URL required'});fetch(url,{headers:{'User-Agent':'SmartieAI/14'}}).then(async r=>{const text=await r.text();const clean=text.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/\s+/g,' ').trim();res.json({url,status:r.status,title:(clean.slice(0,160)||url),text:clean.slice(0,20000)})}).catch(e=>res.status(502).json({error:'Could not fetch page',detail:e.message}))});

app.get('/api/v13/github',(req,res)=>{const q=String(req.query.q||'').trim();if(!q)return res.status(400).json({error:'Repository or search query required'});const url=q.includes('/')&&!q.includes(' ') ? `https://api.github.com/repos/${q}` : `https://api.github.com/search/repositories?q=${encodeURIComponent(q)}&per_page=8`;fetch(url,{headers:{'User-Agent':'SmartieAI/14','Accept':'application/vnd.github+json'}}).then(r=>r.json().then(d=>({ok:r.ok,d}))).then(({ok,d})=>{if(!ok)return res.status(502).json({error:'GitHub request failed',detail:d});const items=d.items||[d];res.json({items:items.slice(0,8).map(x=>({name:x.full_name,description:x.description,stars:x.stargazers_count,language:x.language,url:x.html_url}))})}).catch(e=>res.status(502).json({error:'GitHub request failed',detail:e.message}))});

app.get('/api/v13/voice',(req,res)=>{let x=db.prepare('SELECT * FROM voice_settings WHERE profile_id=?').get(req.v13Session.profile_id);if(!x){x={profile_id:req.v13Session.profile_id,enabled:1,rate:1,pitch:1,voice_name:''};db.prepare('INSERT INTO voice_settings VALUES (?,?,?,?,?)').run(x.profile_id,x.enabled,x.rate,x.pitch,x.voice_name)}res.json(x)});
app.put('/api/v13/voice',(req,res)=>{const x={profile_id:req.v13Session.profile_id,enabled:req.body.enabled===false?0:1,rate:Math.max(.5,Math.min(2,Number(req.body.rate||1))),pitch:Math.max(.5,Math.min(2,Number(req.body.pitch||1))),voice_name:String(req.body.voice_name||'').slice(0,120)};db.prepare('INSERT INTO voice_settings VALUES (?,?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET enabled=excluded.enabled,rate=excluded.rate,pitch=excluded.pitch,voice_name=excluded.voice_name').run(x.profile_id,x.enabled,x.rate,x.pitch,x.voice_name);res.json(x)});

app.get('/api/v13/routines',(req,res)=>res.json(db.prepare('SELECT * FROM routines WHERE profile_id=? ORDER BY next_run').all(req.v13Session.profile_id)));
app.post('/api/v13/routines',(req,res)=>{const t=now(),freq=['hourly','daily','weekdays','weekly'].includes(req.body.frequency)?req.body.frequency:'daily';const x={id:uid('routine'),profile_id:req.v13Session.profile_id,title:String(req.body.title||'Routine').slice(0,140),prompt:String(req.body.prompt||''),frequency:freq,next_run:req.body.next_run||routineNextRun(t,freq),enabled:1,last_run:'',created_at:t,updated_at:t};db.prepare('INSERT INTO routines VALUES (?,?,?,?,?,?,?,?,?,?)').run(Object.values(x));res.json(x)});
app.patch('/api/v13/routines/:id',(req,res)=>{const old=db.prepare('SELECT * FROM routines WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!old)return res.status(404).json({error:'Routine not found'});db.prepare('UPDATE routines SET title=?,prompt=?,frequency=?,next_run=?,enabled=?,updated_at=? WHERE id=?').run(req.body.title??old.title,req.body.prompt??old.prompt,req.body.frequency??old.frequency,req.body.next_run??old.next_run,req.body.enabled===undefined?old.enabled:(req.body.enabled?1:0),now(),old.id);res.json(db.prepare('SELECT * FROM routines WHERE id=?').get(old.id))});
app.delete('/api/v13/routines/:id',(req,res)=>{db.prepare('DELETE FROM routines WHERE id=? AND profile_id=?').run(req.params.id,req.v13Session.profile_id);res.json({ok:true})});
app.post('/api/v13/routines/:id/run',(req,res)=>{const r=db.prepare('SELECT * FROM routines WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!r)return res.status(404).json({error:'Routine not found'});const started=now(),result=`Routine executed locally: ${r.prompt}`;const x={id:uid('run'),routine_id:r.id,profile_id:r.profile_id,started_at:started,finished_at:now(),result};db.prepare('INSERT INTO workflow_runs VALUES (?,?,?,?,?,?)').run(Object.values(x));db.prepare('UPDATE routines SET last_run=?,next_run=?,updated_at=? WHERE id=?').run(started,routineNextRun(started,r.frequency),now(),r.id);res.json(x)});
app.get('/api/v13/workflow-runs',(req,res)=>res.json(db.prepare('SELECT * FROM workflow_runs WHERE profile_id=? ORDER BY started_at DESC LIMIT 50').all(req.v13Session.profile_id)));

app.get('/api/v13/reminders',(req,res)=>res.json(db.prepare('SELECT * FROM reminders WHERE profile_id=? ORDER BY remind_at').all(req.v13Session.profile_id)));
app.post('/api/v13/reminders',(req,res)=>{const t=now();const repeat=['none','daily','weekdays','weekly'].includes(req.body.repeat)?req.body.repeat:'none';const x={id:uid('rem'),profile_id:req.v13Session.profile_id,title:String(req.body.title||'Reminder').slice(0,140),body:String(req.body.body||''),remind_at:new Date(req.body.remind_at||Date.now()).toISOString(),repeat,enabled:1,delivered:0,created_at:t};db.prepare('INSERT INTO reminders VALUES (?,?,?,?,?,?,?,?,?)').run(Object.values(x));res.json(x)});
app.patch('/api/v13/reminders/:id',(req,res)=>{const old=db.prepare('SELECT * FROM reminders WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!old)return res.status(404).json({error:'Reminder not found'});db.prepare('UPDATE reminders SET title=?,body=?,remind_at=?,repeat=?,enabled=?,delivered=? WHERE id=?').run(req.body.title??old.title,req.body.body??old.body,req.body.remind_at??old.remind_at,req.body.repeat??old.repeat,req.body.enabled===undefined?old.enabled:(req.body.enabled?1:0),req.body.delivered===undefined?old.delivered:(req.body.delivered?1:0),old.id);res.json(db.prepare('SELECT * FROM reminders WHERE id=?').get(old.id))});
app.delete('/api/v13/reminders/:id',(req,res)=>{db.prepare('DELETE FROM reminders WHERE id=? AND profile_id=?').run(req.params.id,req.v13Session.profile_id);res.json({ok:true})});
app.get('/api/v13/reminders/due',(req,res)=>res.json(db.prepare("SELECT * FROM reminders WHERE profile_id=? AND enabled=1 AND remind_at<=? AND (delivered=0 OR repeat<>'none') ORDER BY remind_at").all(req.v13Session.profile_id,now())));

app.get('/api/v13/integrations',(req,res)=>res.json(db.prepare('SELECT id,kind,name,enabled,created_at,updated_at FROM integrations WHERE profile_id=? ORDER BY name').all(req.v13Session.profile_id)));
app.post('/api/v13/integrations',(req,res)=>{const t=now(),x={id:uid('int'),profile_id:req.v13Session.profile_id,kind:String(req.body.kind||'webhook').slice(0,60),name:String(req.body.name||'Integration').slice(0,120),config:JSON.stringify(req.body.config||{}),enabled:1,created_at:t,updated_at:t};db.prepare('INSERT INTO integrations VALUES (?,?,?,?,?,?,?,?)').run(Object.values(x));res.json({...x,config:JSON.parse(x.config)} )});
app.patch('/api/v13/integrations/:id',(req,res)=>{const old=db.prepare('SELECT * FROM integrations WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!old)return res.status(404).json({error:'Integration not found'});db.prepare('UPDATE integrations SET name=?,config=?,enabled=?,updated_at=? WHERE id=?').run(req.body.name??old.name,JSON.stringify(req.body.config??JSON.parse(old.config||'{}')),req.body.enabled===undefined?old.enabled:(req.body.enabled?1:0),now(),old.id);res.json(db.prepare('SELECT id,kind,name,enabled,created_at,updated_at FROM integrations WHERE id=?').get(old.id))});
app.delete('/api/v13/integrations/:id',(req,res)=>{db.prepare('DELETE FROM integrations WHERE id=? AND profile_id=?').run(req.params.id,req.v13Session.profile_id);res.json({ok:true})});
app.post('/api/v13/integrations/:id/test',(req,res)=>{const x=db.prepare('SELECT * FROM integrations WHERE id=? AND profile_id=?').get(req.params.id,req.v13Session.profile_id);if(!x)return res.status(404).json({error:'Integration not found'});let cfg={};try{cfg=JSON.parse(x.config||'{}')}catch{}if(x.kind==='webhook'){if(!/^https:\/\//i.test(cfg.url||''))return res.status(400).json({error:'Webhook URL must use HTTPS'});return fetch(cfg.url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:'Smartie AI V13',event:'test',at:now()})}).then(r=>res.json({ok:r.ok,status:r.status})).catch(e=>res.status(502).json({error:'Webhook failed',detail:e.message}))}res.json({ok:true,note:`${x.kind} integration is stored and ready for an explicit provider-specific connector.`})});

app.get('/api/v13/sync/status',(req,res)=>{const x=db.prepare('SELECT updated_at FROM sync_snapshots WHERE profile_id=?').get(req.v13Session.profile_id);res.json({has_snapshot:!!x,updated_at:x?.updated_at||null})});
app.post('/api/v13/sync/push',(req,res)=>{const payload=JSON.stringify(req.body.payload||{});if(payload.length>5*1024*1024)return res.status(413).json({error:'Sync payload too large'});const deviceToken=String(req.body.device_token||'');if(deviceToken.length<16)return res.status(400).json({error:'Device token required'});const h=crypto.createHash('sha256').update(deviceToken).digest('hex');db.prepare('INSERT INTO sync_snapshots VALUES (?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET device_token_hash=excluded.device_token_hash,payload=excluded.payload,updated_at=excluded.updated_at').run(req.v13Session.profile_id,h,payload,now());res.json({ok:true,updated_at:now()})});
app.post('/api/v13/sync/pull',(req,res)=>{const x=db.prepare('SELECT * FROM sync_snapshots WHERE profile_id=?').get(req.v13Session.profile_id);if(!x)return res.json({found:false});const token=String(req.body.device_token||'');const h=crypto.createHash('sha256').update(token).digest('hex');if(h!==x.device_token_hash)return res.status(403).json({error:'Device token does not match'});let payload={};try{payload=JSON.parse(x.payload)}catch{}res.json({found:true,updated_at:x.updated_at,payload})});

app.get('/api/v13/calendar.ics',(req,res)=>{const pid=req.v13Session.profile_id;const tasks=db.prepare("SELECT * FROM tasks WHERE profile_id=? AND due<>'' AND done=0").all(pid);const reminders=db.prepare("SELECT * FROM reminders WHERE profile_id=? AND enabled=1").all(pid);const escIcs=s=>String(s||'').replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\r?\n/g,'\\n');const dt=d=>new Date(d).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Smartie AI V13//EN'];for(const x of tasks)lines.push('BEGIN:VEVENT','UID:'+x.id+'@smartie','DTSTART:'+dt(x.due),'SUMMARY:'+escIcs(x.title),'END:VEVENT');for(const x of reminders)lines.push('BEGIN:VEVENT','UID:'+x.id+'@smartie','DTSTART:'+dt(x.remind_at),'SUMMARY:'+escIcs(x.title),'DESCRIPTION:'+escIcs(x.body),'END:VEVENT');lines.push('END:VCALENDAR');res.setHeader('Content-Type','text/calendar; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="smartie-calendar.ics"');res.send(lines.join('\r\n'))});

setInterval(()=>{const t=now();for(const r of db.prepare("SELECT * FROM reminders WHERE enabled=1 AND remind_at<=?").all(t)){if(r.repeat==='none')db.prepare('UPDATE reminders SET delivered=1 WHERE id=?').run(r.id);else db.prepare('UPDATE reminders SET remind_at=?,delivered=0 WHERE id=?').run(nextReminderTime(r.remind_at,r.repeat),r.id)}for(const r of db.prepare("SELECT * FROM routines WHERE enabled=1 AND next_run<=?").all(t)){const started=now(),result=`Routine checkpoint: ${r.prompt}`;db.prepare('INSERT INTO workflow_runs VALUES (?,?,?,?,?,?)').run(uid('run'),r.id,r.profile_id,started,now(),result);db.prepare('UPDATE routines SET last_run=?,next_run=?,updated_at=? WHERE id=?').run(started,routineNextRun(started,r.frequency),now(),r.id)}},30000);

app.get("/api/health",(req,res)=>res.json({ok:true,version:"v13",title:APP_TITLE}));

app.get("/api/developer",(req,res)=>res.json({
  name:"Makubuya Akram",role:"Creator / Developer",
  public_context:"Creator of Smartie AI and founder/lead builder behind StudySmart UG.",
  projects:["StudySmart UG","StudySmart SmartClass","RuralTech UG / RURALTECH LABS","Kabeja Drinks"]
}));

app.get("/api/profile/:id",(req,res)=>{
  const p=profile(req.params.id); if(!p)return res.status(404).json({error:"Profile not found"}); res.json(p);
});
app.put("/api/profile/:id",(req,res)=>{
  ensureProfile({id:req.params.id,name:req.body.name||"Guest",is_akram:req.params.id==="akram"});
  const p=req.body,t=now();
  db.prepare(`UPDATE profiles SET name=?,country=?,education=?,subjects=?,goals=?,projects=?,style=?,extra=?,updated_at=? WHERE id=?`)
    .run(p.name||"Guest",p.country||"",p.education||"",p.subjects||"",p.goals||"",p.projects||"",p.style||"",p.extra||"",t,req.params.id);
  res.json(profile(req.params.id));
});

app.get("/api/chats/:profileId",(req,res)=>res.json(db.prepare("SELECT * FROM chats WHERE profile_id=? ORDER BY updated_at DESC").all(req.params.profileId)));
app.post("/api/chats",(req,res)=>{
  const p=profile(req.body.profile_id); if(!p)return res.status(404).json({error:"Profile not found"});
  const t=now(),c={id:uid("chat"),profile_id:p.id,title:String(req.body.title||"New conversation").slice(0,120),created_at:t,updated_at:t};
  db.prepare("INSERT INTO chats VALUES (?,?,?,?,?)").run(c.id,c.profile_id,c.title,c.created_at,c.updated_at);res.json(c);
});
app.get("/api/chats/:id/messages",(req,res)=>res.json(db.prepare("SELECT * FROM messages WHERE chat_id=? ORDER BY created_at").all(req.params.id)));
app.post("/api/chats/:id/messages",(req,res)=>{const c=db.prepare("SELECT * FROM chats WHERE id=?").get(req.params.id);if(!c)return res.status(404).json({error:"Chat not found"});const profileId=String(req.body.profile_id||"");if(profileId!==c.profile_id)return res.status(403).json({error:"Profile mismatch"});const msgs=Array.isArray(req.body.messages)?req.body.messages:[];if(!msgs.length||msgs.length>2)return res.status(400).json({error:"Provide one or two messages"});const t=now();const out=[];const tx=db.transaction(()=>{for(const z of msgs){const role=z.role==='assistant'?'assistant':z.role==='user'?'user':'';const content=String(z.content||'').trim();if(!role||!content)continue;const m={id:uid('msg'),chat_id:c.id,role,content,created_at:now()};insertMessage(m);out.push(m)}db.prepare("UPDATE chats SET updated_at=? WHERE id=?").run(t,c.id)});tx();res.json(out)});
app.delete("/api/chats/:id",(req,res)=>{db.prepare("DELETE FROM chats WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/memories/:profileId",(req,res)=>res.json(memoriesFor(req.params.profileId)));
app.post("/api/memories",(req,res)=>{
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const content=String(req.body.content||"").trim();if(!content)return res.status(400).json({error:"Memory content required"});
  const exact=memoriesFor(p.id).find(x=>x.content.toLowerCase()===content.toLowerCase());
  if(exact)return res.json({memory:exact,duplicate:true});
  const t=now(),m={id:uid("mem"),profile_id:p.id,category:req.body.category||"general",importance:req.body.importance||"long-term",content,source_chat_id:req.body.source_chat_id,source_message_id:req.body.source_message_id,confidence:req.body.confidence??1,created_at:t,updated_at:t};
  insertMemory(m);res.json({memory:db.prepare("SELECT * FROM memories WHERE id=?").get(m.id)});
});
app.delete("/api/memories/:id",(req,res)=>{
  const m=db.prepare("SELECT * FROM memories WHERE id=?").get(req.params.id);
  if(m){db.prepare("DELETE FROM memories WHERE id=?").run(m.id);db.prepare("DELETE FROM memories_fts WHERE memory_id=?").run(m.id)}
  res.json({ok:true});
});
app.post("/api/memories/forget",(req,res)=>{
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const found=searchMemories(p.id,req.body.query,50);
  const tx=db.transaction(()=>found.forEach(m=>{db.prepare("DELETE FROM memories WHERE id=?").run(m.id);db.prepare("DELETE FROM memories_fts WHERE memory_id=?").run(m.id)}));
  tx();res.json({forgotten:found.length});
});

app.get("/api/search/messages",(req,res)=>res.json(searchMessages(req.query.profile_id,req.query.q,Number(req.query.limit||30))));
app.get("/api/search/memories",(req,res)=>res.json(searchMemories(req.query.profile_id,req.query.q,Number(req.query.limit||20))));

app.get("/api/brain/search",(req,res)=>{
  const p=profile(req.query.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const q=String(req.query.q||"").trim();if(!q)return res.status(400).json({error:"Query required"});
  const result=brainSearch(p.id,q);res.json({...result,context:brainContext(result)});
});

app.get("/api/projects/:profileId",(req,res)=>res.json(db.prepare("SELECT * FROM projects WHERE profile_id=? ORDER BY updated_at DESC").all(req.params.profileId)));
app.post("/api/projects",(req,res)=>{
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const t=now(),x={id:uid("proj"),profile_id:p.id,name:String(req.body.name||"Untitled project").slice(0,120),description:String(req.body.description||""),status:req.body.status||"active",created_at:t,updated_at:t};
  db.prepare("INSERT INTO projects VALUES (?,?,?,?,?,?,?)").run(x.id,x.profile_id,x.name,x.description,x.status,x.created_at,x.updated_at);res.json(x);
});
app.put("/api/projects/:id",(req,res)=>{
  db.prepare("UPDATE projects SET name=?,description=?,status=?,updated_at=? WHERE id=?")
    .run(req.body.name||"Untitled project",req.body.description||"",req.body.status||"active",now(),req.params.id);
  res.json(db.prepare("SELECT * FROM projects WHERE id=?").get(req.params.id));
});
app.delete("/api/projects/:id",(req,res)=>{db.prepare("DELETE FROM projects WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/tasks/:profileId",(req,res)=>res.json(db.prepare("SELECT * FROM tasks WHERE profile_id=? ORDER BY done,due,created_at DESC").all(req.params.profileId)));
app.post("/api/tasks",(req,res)=>{
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const t=now(),x={id:uid("task"),profile_id:p.id,project_id:req.body.project_id||null,title:String(req.body.title||"Task"),due:req.body.due||"",done:0,created_at:t,updated_at:t};
  db.prepare("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?)").run(x.id,x.profile_id,x.project_id,x.title,x.due,x.done,x.created_at,x.updated_at);res.json(x);
});
app.patch("/api/tasks/:id",(req,res)=>{
  const old=db.prepare("SELECT * FROM tasks WHERE id=?").get(req.params.id);if(!old)return res.status(404).json({error:"Task not found"});
  db.prepare("UPDATE tasks SET title=?,due=?,done=?,updated_at=? WHERE id=?")
    .run(req.body.title??old.title,req.body.due??old.due,req.body.done===undefined?old.done:(req.body.done?1:0),now(),req.params.id);
  res.json(db.prepare("SELECT * FROM tasks WHERE id=?").get(req.params.id));
});
app.delete("/api/tasks/:id",(req,res)=>{db.prepare("DELETE FROM tasks WHERE id=?").run(req.params.id);res.json({ok:true})});

app.post("/api/suggest-memories",async(req,res)=>{
  const key=process.env.OPENROUTER_KEY;if(!key)return res.status(400).json({error:"OPENROUTER_KEY is not configured"});
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  const msgs=Array.isArray(req.body.messages)?req.body.messages.slice(-16):[];
  const prompt=`Extract only useful, non-sensitive long-term facts from this conversation.
Return ONLY a JSON array. Each item: {"content":"...","category":"identity|preference|goal|project|education|general","importance":"permanent|long-term|temporary","confidence":0.0-1.0}.
Do not infer facts. Do not store passwords, API keys, financial secrets, health information, exact addresses, relationship/sexual details or other sensitive private information.
Conversation:
${msgs.map(m=>`${m.role}: ${m.content}`).join("\n")}`;
  try{
    const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`,"HTTP-Referer":process.env.HTTP_REFERER||"","X-Title":APP_TITLE},
      body:JSON.stringify({model:process.env.OPENROUTER_MODEL||"openrouter/free",messages:[
        {role:"system",content:"You are a careful memory extraction engine."},{role:"user",content:prompt}
      ],temperature:.1})});
    const d=await r.json(),txt=d?.choices?.[0]?.message?.content||"[]";
    let items=[];try{items=JSON.parse(txt.replace(/```json|```/g,"").trim())}catch{}
    res.json({suggestions:Array.isArray(items)?items.slice(0,5).filter(x=>x&&x.content):[]});
  }catch(e){res.status(500).json({error:"Memory suggestion failed",detail:e.message})}
});

app.post("/api/chat",async(req,res)=>{
  const key=process.env.OPENROUTER_KEY;if(!key)return res.status(400).json({error:"OPENROUTER_KEY is not configured"});
  const p=profile(req.body.profile_id);if(!p)return res.status(404).json({error:"Profile not found"});
  let chatId=req.body.chat_id;
  if(!chatId){
    const t=now();chatId=uid("chat");
    db.prepare("INSERT INTO chats VALUES (?,?,?,?,?)").run(chatId,p.id,"New conversation",t,t);
  }
  const chat=db.prepare("SELECT * FROM chats WHERE id=? AND profile_id=?").get(chatId,p.id);if(!chat)return res.status(404).json({error:"Chat not found"});
  const userText=String(req.body.message||"").trim();if(!userText)return res.status(400).json({error:"Message required"});
  const userMsg={id:uid("msg"),chat_id:chatId,role:"user",content:userText,created_at:now()};insertMessage(userMsg);

  const brain=brainSearch(p.id,userText);
  const mem=memoriesFor(p.id);
  const memText=mem.length?mem.map(x=>`- [${x.category}/${x.importance}] ${x.content}`).join("\n"):"No saved memories yet.";
  const system=`You are ${APP_TITLE}, a personal AI companion.
${developerContext()}

${profileContext(p)}

SAVED LONG-TERM MEMORY:
${memText}

RETRIEVED BRAIN CONTEXT FOR THIS MESSAGE:
${brainContext(brain)}

RULES:
- Use retrieved context when it genuinely answers or clarifies the user's question.
- Do not invent facts that are not supported by the active profile, memory, retrieved conversation, current conversation or curriculum context.
- Treat old conversation as evidence, not absolute truth. If the user corrects it, accept the correction.
- Never expose another user's private memory.
- Do not claim to remember something unless it appears in supplied context.
- If asked what was previously decided, summarize the retrieved evidence and mention uncertainty when appropriate.
- For school questions, prefer the supplied curriculum context when relevant.
- Be natural and useful.`;

  const curriculum=curriculumContext();
  const history=recentMessages(chatId);
  const messages=[{role:"system",content:system+`\n\nCURRICULUM CONTEXT:\n${curriculum||"No curriculum files have been added."}`},...history];

  try{
    const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`,"HTTP-Referer":process.env.HTTP_REFERER||"","X-Title":APP_TITLE},
      body:JSON.stringify({model:process.env.OPENROUTER_MODEL||"openrouter/free",messages,temperature:.6})});
    const d=await r.json();if(!r.ok)return res.status(502).json({error:"OpenRouter request failed",detail:d});
    const answer=d?.choices?.[0]?.message?.content||"I couldn't generate a response.";
    const assistantMsg={id:uid("msg"),chat_id:chatId,role:"assistant",content:answer,created_at:now()};insertMessage(assistantMsg);
    const count=db.prepare("SELECT COUNT(*) n FROM messages WHERE chat_id=?").get(chatId).n;
    if(chat.title==="New conversation" && count>=2)db.prepare("UPDATE chats SET title=?,updated_at=? WHERE id=?").run(titleGuess(userText),now(),chatId);
    else db.prepare("UPDATE chats SET updated_at=? WHERE id=?").run(now(),chatId);
    res.json({chat_id:chatId,reply:answer,message:assistantMsg,retrieved:{
      memories:brain.memories.slice(0,6),projects:brain.projects.slice(0,6),tasks:brain.tasks.slice(0,6),messages:brain.messages.slice(0,8)
    }});
  }catch(e){res.status(500).json({error:"AI request failed",detail:e.message})}
});


app.get("/api/plans/:profileId",(req,res)=>{
  const plans=db.prepare("SELECT * FROM action_plans WHERE profile_id=? ORDER BY updated_at DESC").all(req.params.profileId);
  const steps=db.prepare("SELECT * FROM action_steps WHERE profile_id=? ORDER BY plan_id,position").all(req.params.profileId);
  res.json(plans.map(p=>({...p,steps:steps.filter(x=>x.plan_id===p.id)})));
});
app.post("/api/plans",(req,res)=>{
  const p=profile(req.body.profile_id); if(!p)return res.status(404).json({error:"Profile not found"});
  const t=now(), x={id:uid("plan"),profile_id:p.id,title:String(req.body.title||"Action plan").slice(0,140),
    goal:String(req.body.goal||""),status:req.body.status||"active",created_at:t,updated_at:t};
  db.prepare("INSERT INTO action_plans VALUES (?,?,?,?,?,?,?)").run(x.id,x.profile_id,x.title,x.goal,x.status,x.created_at,x.updated_at);
  res.json({...x,steps:[]});
});
app.post("/api/plans/:id/steps",(req,res)=>{
  const plan=db.prepare("SELECT * FROM action_plans WHERE id=?").get(req.params.id);
  if(!plan)return res.status(404).json({error:"Plan not found"});
  const count=db.prepare("SELECT COUNT(*) n FROM action_steps WHERE plan_id=?").get(plan.id).n;
  const t=now(),x={id:uid("step"),plan_id:plan.id,profile_id:plan.profile_id,
    title:String(req.body.title||"Step").slice(0,180),details:String(req.body.details||""),
    due:req.body.due||"",done:0,position:count,created_at:t,updated_at:t};
  db.prepare("INSERT INTO action_steps VALUES (?,?,?,?,?,?,?,?,?)").run(
    x.id,x.plan_id,x.profile_id,x.title,x.details,x.due,x.done,x.position,x.created_at,x.updated_at);
  db.prepare("UPDATE action_plans SET updated_at=? WHERE id=?").run(t,plan.id);
  res.json(x);
});
app.patch("/api/action-steps/:id",(req,res)=>{
  const old=db.prepare("SELECT * FROM action_steps WHERE id=?").get(req.params.id);
  if(!old)return res.status(404).json({error:"Action step not found"});
  const done=req.body.done===undefined?old.done:(req.body.done?1:0);
  db.prepare("UPDATE action_steps SET title=?,details=?,due=?,done=?,updated_at=? WHERE id=?")
    .run(req.body.title??old.title,req.body.details??old.details,req.body.due??old.due,done,now(),old.id);
  db.prepare("UPDATE action_plans SET updated_at=? WHERE id=?").run(now(),old.plan_id);
  res.json(db.prepare("SELECT * FROM action_steps WHERE id=?").get(old.id));
});
app.delete("/api/plans/:id",(req,res)=>{
  db.prepare("DELETE FROM action_plans WHERE id=?").run(req.params.id); res.json({ok:true});
});
app.post("/api/actions/from-plan",(req,res)=>{
  const p=profile(req.body.profile_id); if(!p)return res.status(404).json({error:"Profile not found"});
  const plan=db.prepare("SELECT * FROM action_plans WHERE id=? AND profile_id=?").get(req.body.plan_id,p.id);
  if(!plan)return res.status(404).json({error:"Plan not found"});
  const steps=db.prepare("SELECT * FROM action_steps WHERE plan_id=? ORDER BY position").all(plan.id);
  const tx=db.transaction(()=>{
    for(const st of steps){
      const t=now();
      db.prepare("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?)").run(
        uid("task"),p.id,req.body.project_id||null,st.title,st.due,st.done,t,t);
    }
  });
  tx(); res.json({ok:true,created:steps.length});
});
app.post("/api/action-plan/suggest",async(req,res)=>{
  const key=process.env.OPENROUTER_KEY;
  if(!key)return res.status(400).json({error:"OPENROUTER_KEY is not configured"});
  const p=profile(req.body.profile_id); if(!p)return res.status(404).json({error:"Profile not found"});
  const prompt=`Turn the user's request into a realistic action plan.
Return ONLY JSON: {"title":"...","goal":"...","steps":[{"title":"...","details":"...","due":""}]}.
Use 3-8 concrete steps. Do not invent commitments, deadlines, money, contacts or permissions.
If the request is just a question, return a small plan only when an actionable next step is clearly appropriate.
User request: ${String(req.body.request||"").slice(0,5000)}`;
  try{
    const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`,
        "HTTP-Referer":process.env.HTTP_REFERER||"","X-Title":APP_TITLE},
      body:JSON.stringify({model:process.env.OPENROUTER_MODEL||"openrouter/free",
        messages:[{role:"system",content:"You are Smartie's Action Engine. Be practical, conservative and precise."},
                  {role:"user",content:prompt}],temperature:.2})});
    const d=await r.json(); const txt=d?.choices?.[0]?.message?.content||"{}";
    let plan={}; try{plan=JSON.parse(txt.replace(/```json|```/g,"").trim())}catch{}
    plan.steps=Array.isArray(plan.steps)?plan.steps.slice(0,8):[];
    res.json({suggestion:plan});
  }catch(e){res.status(500).json({error:"Action plan generation failed",detail:e.message})}
});

/* ================= V14 AGENT ENGINE ================= */
db.exec(`
CREATE TABLE IF NOT EXISTS v14_agent_plans (id TEXT PRIMARY KEY,profile_id TEXT NOT NULL,title TEXT NOT NULL,goal TEXT NOT NULL,status TEXT DEFAULT 'draft',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS v14_agent_steps (id TEXT PRIMARY KEY,plan_id TEXT NOT NULL,profile_id TEXT NOT NULL,position INTEGER DEFAULT 0,tool TEXT NOT NULL,title TEXT NOT NULL,input_json TEXT DEFAULT '{}',risk TEXT DEFAULT 'low',status TEXT DEFAULT 'pending',result TEXT DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(plan_id) REFERENCES v14_agent_plans(id) ON DELETE CASCADE,FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS v14_permissions (profile_id TEXT NOT NULL,tool TEXT NOT NULL,allowed INTEGER DEFAULT 0,updated_at TEXT NOT NULL,PRIMARY KEY(profile_id,tool),FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS v14_audit (id TEXT PRIMARY KEY,profile_id TEXT NOT NULL,action TEXT NOT NULL,tool TEXT DEFAULT '',detail TEXT DEFAULT '',created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE);
`);
const V14_TOOLS={brain_search:{label:'Search Smartie Brain',risk:'low',description:'Search past conversations, memories, projects and tasks.'},knowledge_search:{label:'Search Knowledge Vault',risk:'low',description:'Search saved documents and notes.'},research_search:{label:'Research the public web',risk:'medium',description:'Find public web sources.'},research_fetch:{label:'Read a public webpage',risk:'medium',description:'Fetch readable text from a public HTTP(S) page.'},create_task:{label:'Create a task',risk:'medium',description:'Create an internal Smartie task.'},create_reminder:{label:'Create a reminder',risk:'medium',description:'Create an internal Smartie reminder.'},save_memory:{label:'Save a memory',risk:'medium',description:'Store an approved long-term memory.'},create_plan:{label:'Create an action plan',risk:'low',description:'Create an internal action plan.'},webhook:{label:'Call an external webhook',risk:'high',description:'Send data to an external HTTPS endpoint.'}};
function audit(pid,action,tool='',detail=''){db.prepare('INSERT INTO v14_audit VALUES (?,?,?,?,?,?)').run(uid('audit'),pid,action,tool,String(detail).slice(0,4000),now())}
function permission(pid,tool){return !!db.prepare('SELECT allowed FROM v14_permissions WHERE profile_id=? AND tool=?').get(pid,tool)?.allowed}
function setPermission(pid,tool,allowed){db.prepare('INSERT INTO v14_permissions VALUES (?,?,?,?) ON CONFLICT(profile_id,tool) DO UPDATE SET allowed=excluded.allowed,updated_at=excluded.updated_at').run(pid,tool,allowed?1:0,now())}
function safeJson(x){try{return JSON.parse(x||'{}')}catch{return {}}}
function localAgentSteps(goal){const g=String(goal).toLowerCase(),s=[];if(/remember|memory|discussed|decided/.test(g))s.push({tool:'brain_search',title:'Search Smartie Brain',input:{query:goal},risk:'low'});if(/research|latest|current|find out|compare|look up|web/.test(g))s.push({tool:'research_search',title:'Research the public web',input:{q:goal},risk:'medium'});if(/document|note|knowledge|file/.test(g))s.push({tool:'knowledge_search',title:'Search Knowledge Vault',input:{q:goal},risk:'low'});if(/task|todo|do next|action/.test(g))s.push({tool:'create_task',title:'Create an execution task',input:{title:goal},risk:'medium'});if(/remind|reminder|tomorrow|later|next week/.test(g))s.push({tool:'create_reminder',title:'Create a reminder',input:{title:goal},risk:'medium'});if(!s.length)s.push({tool:'brain_search',title:'Gather relevant personal context',input:{query:goal},risk:'low'},{tool:'create_plan',title:'Prepare a structured action plan',input:{goal},risk:'low'});return s.slice(0,8)}
async function agentLLMPlan(pid,goal){const key=process.env.OPENROUTER_KEY;if(!key)return null;const b=brainSearch(pid,goal),prompt=`Create a conservative execution plan for this goal: ${goal}\nAvailable tools: ${Object.entries(V14_TOOLS).map(([k,v])=>k+': '+v.description).join('; ')}\nRelevant context:\n${brainContext(b).slice(0,9000)}\nReturn ONLY JSON: {"title":"...","goal":"...","steps":[{"tool":"available tool","title":"...","input":{},"risk":"low|medium|high"}]}. Use 1-8 steps. Never invent permissions, credentials, deadlines, money, contacts, or completed actions.`;try{const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`,'HTTP-Referer':process.env.HTTP_REFERER||'','X-Title':APP_TITLE},body:JSON.stringify({model:process.env.OPENROUTER_MODEL||'openrouter/free',messages:[{role:'system',content:'You are Smartie V14 Agent Planner. Plans are proposals only. Use only listed tools.'},{role:'user',content:prompt}],temperature:.2})});const d=await r.json();if(!r.ok)return null;let text=d?.choices?.[0]?.message?.content||'';text=text.replace(/^```json\s*/,'').replace(/\s*```$/,'').trim();const x=JSON.parse(text);x.steps=Array.isArray(x.steps)?x.steps.filter(s=>V14_TOOLS[s.tool]).slice(0,8):[];return x}catch{return null}}
app.get('/api/v14/health',(req,res)=>res.json({ok:true,version:'v14',engine:'agent',tools:Object.keys(V14_TOOLS)}));
app.use('/api/v14',v13Auth);
app.get('/api/v14/tools',(req,res)=>res.json(Object.entries(V14_TOOLS).map(([id,x])=>({id,...x,allowed:permission(req.v13Session.profile_id,id)}))));
app.get('/api/v14/permissions',(req,res)=>res.json(Object.entries(V14_TOOLS).map(([tool,x])=>({tool,...x,allowed:permission(req.v13Session.profile_id,tool)}))));
app.put('/api/v14/permissions/:tool',(req,res)=>{if(!V14_TOOLS[req.params.tool])return res.status(404).json({error:'Unknown tool'});setPermission(req.v13Session.profile_id,req.params.tool,req.body.allowed===true);audit(req.v13Session.profile_id,'permission_changed',req.params.tool,String(req.body.allowed===true));res.json({tool:req.params.tool,allowed:permission(req.v13Session.profile_id,req.params.tool)})});
app.get('/api/v14/plans',(req,res)=>{const pid=req.v13Session.profile_id,plans=db.prepare('SELECT * FROM v14_agent_plans WHERE profile_id=? ORDER BY updated_at DESC').all(pid),steps=db.prepare('SELECT * FROM v14_agent_steps WHERE profile_id=? ORDER BY plan_id,position').all(pid);res.json(plans.map(p=>({...p,steps:steps.filter(s=>s.plan_id===p.id).map(s=>({...s,input:safeJson(s.input_json)}))})))});
app.post('/api/v14/plan',async(req,res)=>{const pid=req.v13Session.profile_id,goal=String(req.body.goal||'').trim();if(!goal)return res.status(400).json({error:'Goal required'});let x=await agentLLMPlan(pid,goal);if(!x)x={title:'Agent plan',goal,steps:localAgentSteps(goal)};x.steps=(x.steps||[]).filter(s=>V14_TOOLS[s.tool]).slice(0,8);res.json({proposal:{title:String(x.title||'Agent plan').slice(0,160),goal:String(x.goal||goal).slice(0,2000),steps:x.steps.map((s,i)=>({position:i,tool:s.tool,title:String(s.title||V14_TOOLS[s.tool].label).slice(0,180),input:s.input||{},risk:['low','medium','high'].includes(s.risk)?s.risk:V14_TOOLS[s.tool].risk}))}})});
app.post('/api/v14/plans/approve',(req,res)=>{const pid=req.v13Session.profile_id,p=req.body.proposal;if(!p?.goal||!Array.isArray(p.steps))return res.status(400).json({error:'Invalid proposal'});const t=now(),plan={id:uid('agentplan'),profile_id:pid,title:String(p.title||'Agent plan').slice(0,160),goal:String(p.goal).slice(0,2000),status:'approved',created_at:t,updated_at:t};const tx=db.transaction(()=>{db.prepare('INSERT INTO v14_agent_plans VALUES (?,?,?,?,?,?,?)').run(Object.values(plan));p.steps.slice(0,8).forEach((s,i)=>{if(!V14_TOOLS[s.tool])return;db.prepare('INSERT INTO v14_agent_steps VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(uid('agentstep'),plan.id,pid,i,s.tool,String(s.title||V14_TOOLS[s.tool].label).slice(0,180),JSON.stringify(s.input||{}),s.risk||V14_TOOLS[s.tool].risk,'pending','',t,t)});audit(pid,'plan_approved','',plan.id)});tx();res.json({ok:true,plan_id:plan.id})});
async function executeAgentStep(pid,step){const input=safeJson(step.input_json),tool=step.tool;if(!V14_TOOLS[tool])throw Error('Unknown tool');if(!permission(pid,tool))throw Error(`Permission required for ${tool}. Enable it in Agent permissions.`);if(tool==='brain_search')return brainSearch(pid,String(input.query||input.q||''));if(tool==='knowledge_search')return knowledgeResults(pid,String(input.q||input.query||''),12);if(tool==='research_search'){const q=String(input.q||input.query||'').trim();if(!q)throw Error('Research query required');return {query:q,search_url:'https://www.google.com/search?q='+encodeURIComponent(q),note:'Search results must be verified before relying on them.'};}if(tool==='research_fetch'){const url=String(input.url||'');if(!/^https?:\/\//i.test(url))throw Error('Valid http(s) URL required');const r=await fetch(url,{headers:{'User-Agent':'SmartieAI/14'}}),text=await r.text(),clean=text.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/\s+/g,' ').trim();return {url,status:r.status,text:clean.slice(0,12000)};}if(tool==='create_task'){const t=now(),x={id:uid('task'),profile_id:pid,project_id:input.project_id||null,title:String(input.title||step.title).slice(0,180),due:String(input.due||''),done:0,created_at:t,updated_at:t};db.prepare('INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?)').run(Object.values(x));audit(pid,'agent_created_task',tool,x.title);return x;}if(tool==='create_reminder'){const when=input.remind_at||input.when;if(!when)throw Error('Reminder time is required');const t=now(),x={id:uid('rem'),profile_id:pid,title:String(input.title||step.title).slice(0,140),body:String(input.body||''),remind_at:new Date(when).toISOString(),repeat:['none','daily','weekdays','weekly'].includes(input.repeat)?input.repeat:'none',enabled:1,delivered:0,created_at:t};db.prepare('INSERT INTO reminders VALUES (?,?,?,?,?,?,?,?,?)').run(Object.values(x));audit(pid,'agent_created_reminder',tool,x.title);return x;}if(tool==='save_memory'){const t=now(),x={id:uid('mem'),profile_id:pid,category:String(input.category||'general'),importance:String(input.importance||'long-term'),content:String(input.content||step.title).slice(0,3000),source_chat_id:null,source_message_id:null,confidence:Number(input.confidence??.8),created_at:t,updated_at:t};insertMemory(x);audit(pid,'agent_saved_memory',tool,x.content);return x;}if(tool==='create_plan'){const t=now(),x={id:uid('plan'),profile_id:pid,title:String(input.title||'Agent follow-up').slice(0,140),goal:String(input.goal||step.title),status:'active',created_at:t,updated_at:t};db.prepare('INSERT INTO action_plans VALUES (?,?,?,?,?,?,?)').run(Object.values(x));audit(pid,'agent_created_plan',tool,x.title);return x;}if(tool==='webhook'){if(step.risk!=='high')throw Error('External webhook actions must be high risk');const url=String(input.url||'');if(!/^https:\/\//i.test(url))throw Error('Webhook URL must use HTTPS');const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:'Smartie AI V14',event:'agent_action',data:input.data||{},at:now()})});audit(pid,'agent_called_webhook',tool,url);return {ok:r.ok,status:r.status};}}
app.post('/api/v14/plans/:id/execute',async(req,res)=>{const pid=req.v13Session.profile_id,p=db.prepare('SELECT * FROM v14_agent_plans WHERE id=? AND profile_id=?').get(req.params.id,pid);if(!p)return res.status(404).json({error:'Agent plan not found'});if(p.status!=='approved'&&p.status!=='in_progress')return res.status(400).json({error:'Plan must be approved'});const steps=db.prepare('SELECT * FROM v14_agent_steps WHERE plan_id=? AND profile_id=? ORDER BY position').all(p.id,pid),results=[];for(const step of steps){if(step.status==='done')continue;try{const out=await executeAgentStep(pid,step);db.prepare('UPDATE v14_agent_steps SET status=?,result=?,updated_at=? WHERE id=?').run('done',JSON.stringify(out).slice(0,12000),now(),step.id);results.push({id:step.id,tool:step.tool,status:'done',result:out});}catch(e){db.prepare('UPDATE v14_agent_steps SET status=?,result=?,updated_at=? WHERE id=?').run('blocked',e.message,now(),step.id);results.push({id:step.id,tool:step.tool,status:'blocked',result:e.message});break;}}const remaining=db.prepare("SELECT COUNT(*) n FROM v14_agent_steps WHERE plan_id=? AND status<>'done'").get(p.id).n,st=remaining?'in_progress':'completed';db.prepare('UPDATE v14_agent_plans SET status=?,updated_at=? WHERE id=?').run(st,now(),p.id);audit(pid,'agent_plan_executed','',p.id);res.json({plan_id:p.id,status:st,results});});
app.get('/api/v14/audit',(req,res)=>res.json(db.prepare('SELECT id,action,tool,detail,created_at FROM v14_audit WHERE profile_id=? ORDER BY created_at DESC LIMIT 100').all(req.v13Session.profile_id)));

app.get("/api/export/:profileId",(req,res)=>{
  const p=profile(req.params.profileId);if(!p)return res.status(404).json({error:"Profile not found"});
  const chats=db.prepare("SELECT * FROM chats WHERE profile_id=?").all(p.id);
  const messages=db.prepare(`SELECT m.* FROM messages m JOIN chats c ON c.id=m.chat_id WHERE c.profile_id=?`).all(p.id);
  const memories=db.prepare("SELECT * FROM memories WHERE profile_id=?").all(p.id);
  const projects=db.prepare("SELECT * FROM projects WHERE profile_id=?").all(p.id);
  const tasks=db.prepare("SELECT * FROM tasks WHERE profile_id=?").all(p.id);
  const plans=db.prepare("SELECT * FROM action_plans WHERE profile_id=?").all(p.id);
  const steps=db.prepare("SELECT * FROM action_steps WHERE profile_id=?").all(p.id);
  res.json({version:7,exported_at:now(),profile:p,chats,messages,memories,projects,tasks,plans,steps});
});
app.post("/api/import",(req,res)=>{
  const d=req.body||{},p=d.profile;if(!p?.id)return res.status(400).json({error:"Invalid export"});
  ensureProfile(p);
  const tx=db.transaction(()=>{
    for(const c of d.chats||[])db.prepare("INSERT OR REPLACE INTO chats VALUES (?,?,?,?,?)").run(c.id,p.id,c.title,c.created_at,c.updated_at);
    for(const m of d.messages||[]){
      db.prepare("INSERT OR REPLACE INTO messages VALUES (?,?,?,?,?)").run(m.id,m.chat_id,m.role,m.content,m.created_at);
      db.prepare("INSERT OR REPLACE INTO messages_fts VALUES (?,?,?,?)").run(m.id,m.chat_id,p.id,m.content);
    }
    for(const m of d.memories||[]){
      db.prepare("INSERT OR REPLACE INTO memories VALUES (?,?,?,?,?,?,?,?,?,?,?)").run(m.id,p.id,m.category,m.importance,m.content,m.source_chat_id,m.source_message_id,m.confidence,m.status,m.created_at,m.updated_at);
      db.prepare("INSERT OR REPLACE INTO memories_fts VALUES (?,?,?)").run(m.id,p.id,m.content);
    }
    for(const x of d.projects||[])db.prepare("INSERT OR REPLACE INTO projects VALUES (?,?,?,?,?,?,?)").run(x.id,p.id,x.name,x.description,x.status,x.created_at,x.updated_at);
    for(const x of d.tasks||[])db.prepare("INSERT OR REPLACE INTO tasks VALUES (?,?,?,?,?,?,?,?)").run(x.id,p.id,x.project_id,x.title,x.due,x.done,x.created_at,x.updated_at);
    for(const x of d.plans||[])db.prepare("INSERT OR REPLACE INTO action_plans VALUES (?,?,?,?,?,?,?)").run(x.id,p.id,x.title,x.goal,x.status,x.created_at,x.updated_at);
    for(const x of d.steps||[])db.prepare("INSERT OR REPLACE INTO action_steps VALUES (?,?,?,?,?,?,?,?,?)").run(x.id,x.plan_id,p.id,x.title,x.details,x.due,x.done,x.position,x.created_at,x.updated_at);
  });
  try{tx();res.json({ok:true})}catch(e){res.status(400).json({error:"Import failed",detail:e.message})}
});

app.use(express.static(path.join(__dirname,"public")));
app.use((req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`${APP_TITLE} v6 running at http://127.0.0.1:${PORT}`));
