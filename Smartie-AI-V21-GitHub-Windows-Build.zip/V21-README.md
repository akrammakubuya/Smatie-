# Smartie AI V21 - Standalone Android Edition

V21 changes the Android architecture so the installed app does not require the user to open `index.html`, install Node.js, run npm, start Express, or manage project folders.

## Standalone architecture

- Android APK launches the Smartie interface directly.
- A tiny HTTP application server is embedded in the APK and runs only on `127.0.0.1:8787`.
- The bundled interface talks to that embedded server for chats, profiles, memories, projects and tasks.
- SQLite database is stored in Android app-private storage.
- Android native bridge provides speech, reminders, device capability detection and model downloads.
- Cloud AI is optional and uses an OpenRouter key entered in Smartie Settings. The key is stored in Android app storage.
- Local AI model files remain under Android app storage/external app-specific storage.

## User experience

Install one APK -> open Smartie -> use the app.

No Chrome. No Node.js. No npm. No server.js. No project folder.

## Important build note

This repository contains the Android V21 source project. A compiled APK still requires an Android SDK/Gradle build environment. The current build workspace used to create this source package does not include those build tools, so this package is not falsely labelled as a compiled APK.
