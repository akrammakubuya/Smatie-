# Smartie AI V21 - GitHub Windows Build

This package includes a GitHub Actions workflow that builds Smartie AI V21 on a hosted Windows machine.

## What you need

- A GitHub account
- A repository containing this project
- For the simplest free build route, make the repository public

## Upload the project

1. Create a GitHub repository, for example `Smartie-AI-V21`.
2. Upload the **contents of this ZIP**, not the ZIP file itself.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Smartie AI V21 for Windows**.
6. Click **Run workflow**.
7. Wait for the Windows runner to finish.
8. Open the completed workflow run.
9. At the bottom, download the artifact named **Smartie-AI-V21-Windows**.
10. Extract the artifact and test the portable EXE first.

## Expected output

The build produces:

- `Smartie-AI-V21-21.0.0-x64.exe` - Windows installer
- `Smartie-AI-V21-21.0.0-portable.exe` - portable version

## Security

Do **not** put an OpenRouter API key, password, token, or other secret into this repository or workflow.

Smartie should receive the OpenRouter key through its application settings/environment at runtime rather than committing it to GitHub.

## Important

The GitHub workflow builds the Windows desktop application. It does not require you to open `index.html` or manually start `server.js` on the finished desktop application.
