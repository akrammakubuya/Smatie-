# Smartie Personal V15

V15 adds a native Android companion layer to V14.

## Major additions
- Native Android WebView shell with bundled Smartie UI
- Native Text-to-Speech bridge
- Android reminder notifications using AlarmManager
- Android 13+ notification permission handling
- Native connectivity bridge
- Configurable Smartie server URL for the phone app
- Offline-first UI shell and browser storage retained
- V13 cloud/security foundations retained
- V14 agent planning, permissions, execution and audit retained

## Run the server
The Node server remains the backend for AI, SQLite data, research, cloud sync and agent APIs. Copy `.env.example` to `.env`, set `OPENROUTER_KEY`, then run `npm install` and `npm start`.

## Android
Open `android/` in Android Studio and build the app. On first run, open Settings and enter the reachable Node server URL, for example `http://192.168.1.10:3000`. Android's local-network cleartext policy is enabled for development. For production, use HTTPS.

## Important limits
The bundled Android shell works offline as an interface, but cloud AI and server-backed features need a reachable backend. V15 does not bundle a large language model. Exact-alarm behavior depends on Android permissions and device policy. A future production build should persist alarm IDs, use encrypted local storage, add robust sync conflict resolution, and integrate an on-device model where hardware permits.
