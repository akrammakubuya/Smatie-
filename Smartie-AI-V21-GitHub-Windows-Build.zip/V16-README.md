# Smartie Personal Phone Deploy V16

V16 builds on V15 with a Samsung/Android-focused native layer and an offline-AI-ready architecture.

## New in V16
- Device capability detection (manufacturer, model, Android version, RAM).
- Local AI adapter: configure a local OpenAI-compatible endpoint such as a model server running on the phone/LAN. V16 does not bundle a large model.
- Cloud-first/local-fallback architecture can be wired from the web UI.
- Persistent native alarm registry.
- Alarm restoration after device reboot/app update.
- Exact-alarm permission handling on Android 12+.
- Samsung-friendly battery optimization settings shortcut.
- Native cancellation for scheduled reminders.
- Native TTS, notifications and connectivity from V15 retained.

## Samsung note
Samsung S-series phones vary widely. V16 detects the actual device at runtime rather than assuming a particular S model. For reliable background reminders, users should set Smartie to an unrestricted battery setting where available.

## Local AI
A suitable small on-device model and runtime still need to be installed separately. The adapter accepts an OpenAI-compatible chat-completions endpoint. This keeps the APK practical and avoids pretending a large model is included.
