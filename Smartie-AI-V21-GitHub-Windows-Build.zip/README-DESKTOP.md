# Smartie AI V21 - Windows Desktop Edition

This edition wraps the V21 Smartie backend and interface in Electron so the user does not open `index.html` or manually start `server.js`.

## User experience

- Install `Smartie-AI-V21-21.0.0-x64.exe`, or use the portable build.
- Launch Smartie AI V21 from the Start Menu/Desktop.
- The app starts its local application server automatically and opens its own window.
- Data is stored in the Windows app-data directory, not beside the executable.
- Chrome is not required for normal use.

## Developer build

Requirements: Windows 10/11, Node.js 20+ and npm, plus internet access for the first dependency install.

From this folder:

```powershell
npm install
npm run dev
```

Build both installer and portable EXE:

```powershell
npm run dist
```

Outputs are placed in `dist/`.

### Installer only

```powershell
npm run dist:installer
```

### Portable EXE only

```powershell
npm run dist:portable
```

## Cloud AI

Do not hard-code an API key into the desktop source. Configure the OpenRouter key through the Smartie UI/settings if the V21 UI supports it, or through a secure environment/config mechanism during development.

## Architecture

Electron main process -> embedded Express server -> bundled Smartie UI -> local SQLite in `%APPDATA%/smartie-ai-v21-desktop/data`.

The original Node server is an implementation component inside the desktop app, not something the user runs manually.
