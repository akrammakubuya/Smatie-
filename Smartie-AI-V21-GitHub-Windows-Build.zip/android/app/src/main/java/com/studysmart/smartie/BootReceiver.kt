package com.studysmart.smartie

import android.app.*
import android.content.*
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val prefs = context.getSharedPreferences("smartie_v16", Context.MODE_PRIVATE)
        val alarms = prefs.getStringSet("alarms", emptySet()) ?: emptySet()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.forEach { row ->
            val parts = row.split("|", limit=4)
            if (parts.size < 4) return@forEach
            val id = parts[0].toIntOrNull() ?: return@forEach
            val at = parts[1].toLongOrNull() ?: return@forEach
            if (at <= System.currentTimeMillis()) return@forEach
            val pi = PendingIntent.getBroadcast(context, id, Intent(context, ReminderReceiver::class.java).apply { putExtra("id", id); putExtra("title", parts[2]); putExtra("body", parts[3]) }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.set(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
