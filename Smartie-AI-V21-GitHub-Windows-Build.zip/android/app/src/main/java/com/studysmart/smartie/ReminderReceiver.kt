package com.studysmart.smartie

import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channel = "smartie_reminders"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(channel, "Smartie reminders", NotificationManager.IMPORTANCE_HIGH))
        val title = intent.getStringExtra("title") ?: "Smartie reminder"
        val body = intent.getStringExtra("body") ?: "You have a reminder."
        val n = NotificationCompat.Builder(context, channel).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
}
