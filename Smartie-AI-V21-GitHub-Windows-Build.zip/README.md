# Smartie Personal Phone Deploy V18

V18 is the Adaptive Runtime & Model Manager release. It detects device capabilities, benchmarks the device, verifies a real local AI runtime when configured, and recommends local, hybrid, or cloud-first operation without assuming every Android phone can run the same model.

See `V18-README.md` for the full architecture and limitations.


## V19
V19 adds the Smart Model Manager and adaptive local/cloud router. See V19-README.md.
