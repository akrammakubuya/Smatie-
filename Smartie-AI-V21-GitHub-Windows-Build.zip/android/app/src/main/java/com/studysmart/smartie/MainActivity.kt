package com.studysmart.smartie

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.speech.tts.TextToSpeech
import android.provider.Settings
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.*
import java.io.File
import android.os.Environment

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("smartie_v21", MODE_PRIVATE) }
    private lateinit var localServer: LocalServer
    private val downloadPrefs by lazy { getSharedPreferences("smartie_v20_downloads", MODE_PRIVATE) }
    private val io = Executors.newCachedThreadPool()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        setContentView(web)
        localServer = LocalServer(this)
        localServer.start()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(NativeBridge(this), "SmartieNative")
        web.loadUrl("http://127.0.0.1:8787/index.html")
        requestNotificationPermission()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale.UK }
    fun speak(text: String, rate: Float, pitch: Float) { tts.setSpeechRate(rate); tts.setPitch(pitch); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "smartie") }
    fun stopSpeak() { tts.stop() }
    fun schedule(title: String, body: String, at: Long) {
        val id = (at xor title.hashCode().toLong()).toInt()
        val intent = Intent(this, ReminderReceiver::class.java).apply { putExtra("id", id); putExtra("title", title); putExtra("body", body) }
        val pi = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) } catch (_: Exception) {}
        }
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.set(AlarmManager.RTC_WAKEUP, at, pi)
        val alarms = prefs.getStringSet("alarms", emptySet())!!.toMutableSet()
        alarms.removeAll { it.startsWith("$id|") }
        alarms.add("$id|$at|${title.replace("|", " ")}|${body.replace("|", " ")}")
        prefs.edit().putStringSet("alarms", alarms).apply()
    }
    fun cancel(title: String) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val alarms = prefs.getStringSet("alarms", emptySet())!!.toMutableSet()
        val matches = alarms.filter { it.split("|").getOrNull(2) == title }
        matches.forEach { val id = it.substringBefore("|").toIntOrNull() ?: return@forEach; val pi = PendingIntent.getBroadcast(this, id, Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE); if (pi != null) am.cancel(pi); alarms.remove(it) }
        prefs.edit().putStringSet("alarms", alarms).apply()
    }
    fun capabilityInfo(): String {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val cores = Runtime.getRuntime().availableProcessors()
        val ramGb = mi.totalMem / 1073741824.0
        val lowRam = am.isLowRamDevice
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val stat = try { android.os.StatFs(filesDir.absolutePath); android.os.StatFs(filesDir.absolutePath) } catch (_: Exception) { null }
        val freeGb = if (stat != null) stat.availableBytes / 1073741824.0 else -1.0
        val battery = try {
            val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
            bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (_: Exception) { -1 }
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            pm.currentThermalStatus
        } else -1
        val tier = when { lowRam || ramGb < 2.5 || cores < 4 -> "cloud-first"; ramGb < 4.0 -> "tiny-local"; ramGb < 6.0 -> "small-local"; ramGb < 8.0 -> "medium-local"; else -> "strong-local" }
        val maxModel = when (tier) { "cloud-first" -> "Cloud only / tiny helper"; "tiny-local" -> "0.5B-1B quantized"; "small-local" -> "1B-2B quantized"; "medium-local" -> "2B-4B quantized"; else -> "3B-7B quantized" }
        return JSONObject().put("platform", "Android").put("manufacturer", Build.MANUFACTURER).put("model", Build.MODEL).put("android", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT).put("ramGb", String.format("%.1f", ramGb)).put("cores", cores).put("abi", abi).put("freeStorageGb", String.format("%.1f", freeGb)).put("batteryPercent", battery).put("thermalStatus", thermal).put("lowRamDevice", lowRam).put("samsung", Build.MANUFACTURER.equals("samsung", true)).put("tier", tier).put("recommendedModelSize", maxModel).put("supportsLocalRuntimeAdapter", true).put("supportsBenchmark", true).toString()
    }
    fun benchmarkCpu(): String {
        val start = System.nanoTime(); var x = 0L
        for (i in 1..1500000) x = (x + i * 31L) xor (x shl 1)
        val ms = (System.nanoTime() - start) / 1_000_000.0
        return JSONObject().put("elapsedMs", ms).put("workUnits", 1500000).put("checksum", x).toString()
    }
    fun deviceInfo(): String {
        val mem = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); mem.getMemoryInfo(mi)
        return JSONObject().put("manufacturer", Build.MANUFACTURER).put("model", Build.MODEL).put("android", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT).put("ramGb", String.format("%.1f", mi.totalMem / 1073741824.0)).put("samsungOptimized", Build.MANUFACTURER.equals("samsung", true)).toString()
    }
    fun openBatterySettings() {
        try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    fun modelDownload(id:String, url:String, name:String, sha256:String):String {
        if(url.isBlank()) return JSONObject().put("ok",false).put("error","Model URL is required").toString()
        val wm=WorkManager.getInstance(this)
        val data=workDataOf(ModelDownloadWorker.KEY_ID to id, ModelDownloadWorker.KEY_URL to url, ModelDownloadWorker.KEY_NAME to name, ModelDownloadWorker.KEY_SHA to sha256)
        val req=OneTimeWorkRequestBuilder<ModelDownloadWorker>().setInputData(data).addTag("smartie_model_$id").build()
        wm.enqueueUniqueWork("smartie_model_$id", ExistingWorkPolicy.REPLACE, req)
        downloadPrefs.edit().putString("$id.status","queued").putString("$id.name",name).apply()
        return JSONObject().put("ok",true).put("workId",req.id.toString()).toString()
    }
    fun modelPause(id:String):String { WorkManager.getInstance(this).cancelUniqueWork("smartie_model_$id"); downloadPrefs.edit().putString("$id.status","paused").apply(); return JSONObject().put("ok",true).toString() }
    fun modelCancel(id:String):String { WorkManager.getInstance(this).cancelUniqueWork("smartie_model_$id"); val f=downloadPrefs.getString("$id.file",null)?.let{File(it)}; if(f?.exists()==true) f.delete(); downloadPrefs.edit().remove("$id.file").putString("$id.status","cancelled").apply(); return JSONObject().put("ok",true).toString() }
    fun modelStatus(id:String):String {
        val infos=WorkManager.getInstance(this).getWorkInfosForUniqueWork("smartie_model_$id").get()
        val w=infos.firstOrNull(); val s=downloadPrefs.getString("$id.status","not_started") ?: "not_started"
        val bytes=downloadPrefs.getLong("$id.bytes",0); val total=downloadPrefs.getLong("$id.total",0)
        val pct=if(total>0)(bytes*100/total).toInt() else 0
        return JSONObject().put("id",id).put("status",s).put("workState",w?.state?.name ?: "NONE").put("progress",pct).put("bytes",bytes).put("total",total).put("file",downloadPrefs.getString("$id.file",null)).toString()
    }
    fun modelDelete(id:String):String { modelCancel(id); val f=downloadPrefs.getString("$id.file",null)?.let{File(it)}; if(f?.exists()==true)f.delete(); downloadPrefs.edit().remove("$id.file").remove("$id.status").remove("$id.bytes").remove("$id.total").apply(); return JSONObject().put("ok",true).toString() }
    fun modelFiles():String { val dir=File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"models"); val arr=org.json.JSONArray(); dir.listFiles()?.filter{it.isFile}?.forEach{arr.put(JSONObject().put("name",it.name).put("path",it.absolutePath).put("bytes",it.length()))}; return JSONObject().put("files",arr).toString() }

    fun localChat(endpoint: String, payload: String, callback: (String)->Unit) {
        io.execute {
            val result = try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply { requestMethod="POST"; connectTimeout=8000; readTimeout=30000; doOutput=true; setRequestProperty("Content-Type","application/json") }
                OutputStreamWriter(conn.outputStream).use { it.write(payload) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                stream.bufferedReader().use { it.readText() }
            } catch (e: Exception) { JSONObject().put("error", e.message ?: "Local AI unavailable").toString() }
            runOnUiThread { callback(result) }
        }
    }

    override fun onDestroy() { try { localServer.stop() } catch (_: Exception) {}; tts.stop(); tts.shutdown(); super.onDestroy() }
}

class NativeBridge(private val a: MainActivity) {
    @JavascriptInterface fun isAndroid(): Boolean = true
    @JavascriptInterface fun speak(text: String, rate: Float, pitch: Float) = a.runOnUiThread { a.speak(text, rate, pitch) }
    @JavascriptInterface fun stopSpeaking() = a.runOnUiThread { a.stopSpeak() }
    @JavascriptInterface fun notify(title: String, body: String, atMillis: Long) = a.schedule(title, body, atMillis)
    @JavascriptInterface fun cancelNotification(title: String) = a.cancel(title)
    @JavascriptInterface fun deviceInfo(): String = a.deviceInfo()
    @JavascriptInterface fun capabilityInfo(): String = a.capabilityInfo()
    @JavascriptInterface fun benchmarkCpu(): String = a.benchmarkCpu()
    @JavascriptInterface fun openBatterySettings() = a.runOnUiThread { a.openBatterySettings() }
    @JavascriptInterface fun localChat(endpoint: String, payload: String, callbackName: String) {
        a.localChat(endpoint, payload) { result -> a.web.evaluateJavascript("window[${JSONObject.quote(callbackName)}](${JSONObject.quote(result)});", null) }
    }
    @JavascriptInterface fun modelDownload(id:String,url:String,name:String,sha256:String):String = a.modelDownload(id,url,name,sha256)
    @JavascriptInterface fun modelPause(id:String):String = a.modelPause(id)
    @JavascriptInterface fun modelCancel(id:String):String = a.modelCancel(id)
    @JavascriptInterface fun modelStatus(id:String):String = a.modelStatus(id)
    @JavascriptInterface fun modelDelete(id:String):String = a.modelDelete(id)
    @JavascriptInterface fun modelFiles():String = a.modelFiles()
    @JavascriptInterface fun getCloudKey(): String = a.getSharedPreferences("smartie_v21", Context.MODE_PRIVATE).getString("openrouter_key", "") ?: ""
    @JavascriptInterface fun setCloudKey(key: String): Boolean { a.getSharedPreferences("smartie_v21", Context.MODE_PRIVATE).edit().putString("openrouter_key", key.trim()).apply(); return true }
    @JavascriptInterface fun getCloudModel(): String = a.getSharedPreferences("smartie_v21", Context.MODE_PRIVATE).getString("openrouter_model", "openrouter/free") ?: "openrouter/free"
    @JavascriptInterface fun setCloudModel(model: String): Boolean { a.getSharedPreferences("smartie_v21", Context.MODE_PRIVATE).edit().putString("openrouter_model", model.trim().ifBlank { "openrouter/free" }).apply(); return true }
    @JavascriptInterface fun networkOnline(): Boolean = try { val cm = a.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager; cm.activeNetwork != null } catch (_: Exception) { false }
    @JavascriptInterface fun networkType(): String = try { val cm = a.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager; val n=cm.activeNetwork ?: return "offline"; val c=cm.getNetworkCapabilities(n) ?: return "unknown"; when { c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"; c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"; c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"; else -> "other" } } catch (_: Exception) { "unknown" }
}
