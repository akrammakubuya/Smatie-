# Smartie AI V19 - Smart Model Manager & Adaptive AI Router

V19 builds on V18 and adds a device-aware local-model selection layer.

## Core behavior
- Keeps hardware detection and runtime verification from V18.
- Stores local model profiles on the device.
- A model is marked verified only after an OpenAI-compatible runtime responds to a probe.
- Chooses local AI only when a verified model exists and device conditions are reasonable.
- Falls back to the existing cloud `/api/chat` path if local inference is unavailable or fails.
- Considers battery and Android thermal status before local routing.
- Provides model-size candidates rather than forcing a single model onto every phone.

## Important
V19 does not silently download large model files. Users or a future trusted model installer can provide a local runtime/model. This avoids pretending that every Android phone can run the same model and avoids untrusted automatic downloads.

## Android
The Android project is version 19.0.0 and retains the native bridge from earlier versions. Local model runtimes can be exposed through the existing OpenAI-compatible local endpoint bridge.

## Local chat persistence
When a verified local model answers, V19 writes the user/assistant exchange back to the same Smartie chat database so local conversations do not disappear from history.
