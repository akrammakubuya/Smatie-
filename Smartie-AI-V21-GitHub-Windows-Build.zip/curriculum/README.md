# Curriculum Knowledge

Add NCDC-aligned `.md` or `.txt` files here.

Suggested structure:
- s5_mathematics.md
- s5_economics.md
- s5_geography.md
- s5_ict.md

Smartie loads these files as curriculum context for relevant school questions.
