
self.addEventListener("notificationclick", event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:"window", includeUncontrolled:true}).then(list=>{
    if(list.length) return list[0].focus();
    return clients.openWindow("/");
  }));
});
self.addEventListener("push", event => {
  let data={title:"Smartie",body:"You have a Smartie notification."};
  try { data=event.data.json(); } catch(e) {}
  event.waitUntil(self.registration.showNotification(data.title||"Smartie",{
    body:data.body||"",
    icon:"/icon-192.png",
    badge:"/icon-192.png",
    tag:data.tag||"smartie"
  }));
});
