const { app, BrowserWindow, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const PORT = 31821;
process.env.PORT = String(PORT);
process.env.APP_TITLE = 'Smartie AI V21';
process.env.SMARTIE_DATA_DIR = path.join(app.getPath('userData'), 'data');
fs.mkdirSync(process.env.SMARTIE_DATA_DIR, { recursive: true });

let serverStarted = false;
let mainWindow;

function startEmbeddedServer() {
  try {
    require(path.join(__dirname, '..', 'server.js'));
    serverStarted = true;
  } catch (err) {
    dialog.showErrorBox('Smartie V21 could not start', String(err.stack || err));
    app.quit();
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    title: 'Smartie AI V21',
    backgroundColor: '#0b1020',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.loadURL(`http://127.0.0.1:${PORT}`);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  startEmbeddedServer();
  setTimeout(createWindow, 350);
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
