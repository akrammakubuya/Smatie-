# Smartie Personal Phone Deploy V12

V12 adds the Reminder & Notification Engine.

Features:
- One-time reminders.
- Daily, weekday and weekly recurring reminders.
- Enable/pause/delete reminders.
- Browser notification permission flow.
- PWA service worker registration and notification click handling.
- Due-reminder polling while the Smartie web app is active.
- Server-side reminder state management and recurring date advancement.
- Works per profile.

V11 Automation, V10 Voice, V9 Knowledge, V8 Proactive, V7 Actions, V6 Brain, V5 Memory and earlier features remain included.

Important platform limitation:
A normal browser/PWA cannot guarantee JavaScript execution at an exact future time after Android suspends/kills the app. This version therefore provides real browser notifications when the PWA is active and prepares the service-worker layer for future push/Android integration. True reliable background alarms/push require a platform push service or native Android/OS scheduling layer.
