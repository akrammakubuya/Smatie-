# Smartie Personal Phone Deploy V13

V13 is the consolidation release. It keeps the V1-V12 project and adds the remaining foundation pieces in one deployable package.

## Added in V13
- Server-side profile password setup/login with scrypt hashing, expiring HttpOnly sessions and basic login rate limiting.
- Profile-scoped V13 APIs.
- Server sync snapshots for moving a profile between devices running the same deployment. A private device token is required to pull a snapshot.
- Controlled public web research: search result discovery plus explicit page inspection.
- Public GitHub repository lookup.
- Knowledge Vault with SQLite FTS search for pasted/imported text.
- Lightweight personal knowledge graph built from profile, projects, memories and tasks.
- Personalization preferences for response style/detail and feature toggles.
- Voice settings backed by browser/device speech synthesis.
- Automation routines and workflow history.
- Reminder center with recurring reminders and server-side date advancement.
- Calendar export as `.ics`.
- Explicit HTTPS webhook integrations. No silent external account actions.
- V13 Control Center that exposes the new engines.

## Important boundaries
- Reliable Android background notifications still require a native Android scheduler or push service. A normal browser/PWA cannot guarantee execution after Android kills/suspends the app.
- Gmail, Google Drive, Google Calendar and WhatsApp are not faked as connected. Provider OAuth/API credentials and provider-specific connectors are required before those services can be used.
- Web research returns unverified public sources. Important claims should be checked against primary/official sources.
- Sync stores the latest snapshot on the server. Use HTTPS in any deployment reachable over a network.
- V13 security protects the new V13 routes. The legacy V1-V12 routes remain compatible and are not automatically protected by the V13 login layer. For a public production deployment, add HTTPS, a reverse proxy, strict authentication middleware and secure secret management.
- Do not put OpenRouter keys in frontend code. Keep `OPENROUTER_KEY` in `.env` on the server.

## Run
1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `OPENROUTER_KEY`.
4. Run `npm start`.
5. Open the displayed local address.
6. Open **Command** and create a V13 password for the active profile.

## Existing engines retained
Memory, Brain, Actions, Proactive intelligence, Knowledge, Voice, Automation and Reminders are retained in the project lineage. V13 adds a working server implementation for the engines that were previously only partially wired in the phone package.
