# Smartie AI V14

V14 adds the Agent Engine on top of V13.

## Agent model

Smartie can turn a natural-language goal into a reviewable execution proposal. The user must approve the proposal before it is stored as an executable plan, and each tool is checked against an explicit per-profile permission before execution.

## Included tools

- Brain search
- Knowledge Vault search
- Public web research handoff
- Public webpage fetch
- Create internal task
- Create internal reminder
- Save memory
- Create internal action plan
- HTTPS webhook action

## Safety and control

- Permissions are off by default.
- Plans are proposals until explicitly approved.
- Every executed step checks permission again.
- External webhook actions are high-risk and require an HTTPS URL.
- Agent actions are recorded in an audit trail.
- Agent execution is profile-scoped through the V13 session system.
- No silent Gmail, WhatsApp, Drive, Calendar or other account access is fabricated.

## Important limitation

V14 is an agent foundation, not a native Android agent. Browser/PWA background execution and Android OS scheduling still require a native Android layer or push service for guaranteed background behavior.
